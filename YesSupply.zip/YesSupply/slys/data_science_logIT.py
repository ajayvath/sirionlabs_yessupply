#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import statsmodels.api as sm

#Loading Training Set
dataset = pd.read_csv(r'C:\slys\data\SirionLabsSample1.csv')

dataset.rename(columns = {'Average Delivery Time':'AverageDeliveryTime'}, inplace = True)
dataset.rename(columns = {'Number of Escalations':'NumberofEscalations'}, inplace = True)

dataset['Selected_Flag'] = dataset['Selected_Flag'].map({'Y':1, 'N':0})

#Categorical Columns - Using one hot encoding to include the columns in data analysis.

dataset_regions = pd.get_dummies(dataset['Region'])
dataset = dataset.join(dataset_regions)
dataset.drop('Region',axis=1, inplace=True)

dataset_functions = pd.get_dummies(dataset['Function'])
dataset = dataset.join(dataset_functions)
dataset.drop('Function',axis=1, inplace=True)

dataset_service = pd.get_dummies(dataset['Services'])
dataset = dataset.join(dataset_service)
dataset.drop('Services',axis=1, inplace=True)

dataset_country = pd.get_dummies(dataset['Country'])
dataset = dataset.join(dataset_country)
dataset.drop('Country',axis=1, inplace=True)

#:::NO OUTPUT in Yes-Supply::: Verifying null (NaNs) in OHE data
dataset_functions.isnull().values.any()
dataset_regions.isnull().values.any()
dataset_service.isnull().values.any()
dataset_country.isnull().values.any()

# Put the selection at the back
dataset = dataset.reindex(columns = [col for col in dataset.columns if col != 'Selected_Flag'] + ['Selected_Flag'])

#Selecting all features except Supplier Name as it is a Key column
x = dataset.iloc[:,1:-1].values
y = dataset.iloc[:,-1:].values

#LogIT Model implementation
result_log = sm.Logit(y, x).fit()

#:::NO OUTPUT in Yes-Supply::: Summarizing Statistical Information 
result_log.summary()

#:::NO OUTPUT in Yes-Supply::: Confusion Matrix Calculation
cm = result_log.pred_table()
cm

i_total_true = cm[0][0] + cm[1][1]
i_total_false = cm[1][0] + cm[0][1]

sigma = i_total_true + i_total_false

accuracy = str((round(i_total_true/sigma,4) * 100)) 
print('Model Accuracy - ', accuracy,"%" )

#Applying model on Actual data
dataset_act = pd.read_csv(r'C:\slys\data\SirionLabsSample_Act.csv')

dataset_act.rename(columns = {'Average Delivery Time':'AverageDeliveryTime'}, inplace = True)
dataset_act.rename(columns = {'Number of Escalations':'NumberofEscalations'}, inplace = True)


dataset_act_regions = pd.get_dummies(dataset_act['Region'])
dataset_act = dataset_act.join(dataset_act_regions)
dataset_act.drop('Region',axis=1, inplace=True)

dataset_act_functions = pd.get_dummies(dataset_act['Function'])
dataset_act = dataset_act.join(dataset_act_functions)
dataset_act.drop('Function',axis=1, inplace=True)

dataset_act_service = pd.get_dummies(dataset_act['Services'])
dataset_act = dataset_act.join(dataset_act_service)
dataset_act.drop('Services',axis=1, inplace=True)

dataset_country = pd.get_dummies(dataset_act['Country'])
dataset_act = dataset_act.join(dataset_country)
dataset_act.drop('Country',axis=1, inplace=True)


x_act = dataset.iloc[:,1:-1].values
y_test_data_pred = result_log.predict(x_act)



x_key = pd.DataFrame(dataset_act['Supplier Name'])
dataset_test_result = pd.DataFrame({'Selected Flag':y_test_data_pred})
dataset_test_result = dataset_test_result.astype(int)
merged = pd.concat([x_key,dataset_test_result],axis=1)

merged['Selected Flag'] = merged['Selected Flag'].map({1:'Y', 0:'N'})
merged.to_csv('fin_sirionlabs_logit.csv', index=False)



merged.to_csv(r'C:\slys\extracts\extract_models_SirionLabsSample_Act.csv' , index=False)