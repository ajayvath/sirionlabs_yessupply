import pandas as pd

dataset = pd.read_csv(r'C:\slys\data\SirionLabsSample1.csv')
dataset.describe().to_csv(r'C:\slys\extracts\extract_report_SirionLabsSample1.csv')