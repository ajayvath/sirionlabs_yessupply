﻿Public Class YSMainMenu
    Private Sub AddSupplierToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AddSupplierToolStripMenuItem.Click
        Me.Hide()
        Add_Supplier.Show()
    End Sub

    Private Sub ManageRulesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ManageRulesToolStripMenuItem.Click
        Me.Hide()
        ManageRuleEngine.Show()
    End Sub

    Private Sub ViewProfileDataToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ViewProfileDataToolStripMenuItem.Click
        Me.Hide()
        ViewSuppliers.Show()
    End Sub

    Private Sub Back_Click(sender As Object, e As EventArgs) Handles Back.Click
        Dim vbAns = MsgBox("Are you sure you want to close Sirion Lab's Yes-Supply?", vbYesNo + vbInformation, "Yes-Supply: Confirmation")
        If vbAns = vbYes Then
            Me.Close()
        Else
            'Do Nothiong
        End If
    End Sub

    Private Sub ApplyRuleEngineToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ApplyRuleEngineToolStripMenuItem.Click
        Me.Hide()
        ApplyRule.Show()
    End Sub

    Private Sub DeployAlgorithmToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DeployAlgorithmToolStripMenuItem.Click
        Me.Hide()
        DeployModel.Show()
    End Sub

    Private Sub ApplyAlgorithmToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ApplyAlgorithmToolStripMenuItem.Click
        Me.Hide()
        ApplyModel.Show()
    End Sub

    Private Sub ManageCSVProfileToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ManageCSVProfileToolStripMenuItem.Click
        Me.Hide()
        NewProfile.Show()
    End Sub

    Private Sub ProfileDescribeToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ProfileDescribeToolStripMenuItem.Click
        Me.Hide()
        ProfileDescribe.Show()
    End Sub
End Class
