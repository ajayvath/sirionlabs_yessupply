﻿Imports System.IO
Imports System.Xml
Public Class YSMainMenu
    Dim xmlTrProfdoc As New XmlDataDocument()
    Dim xmlRuledoc As New XmlDataDocument()
    Dim xmlModeldoc As New XmlDataDocument()
    Dim xmlnode As XmlNodeList
    Private Sub AddSupplierToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AddSupplierToolStripMenuItem.Click
        Me.Hide()
        Add_Supplier.Show()
    End Sub
    Private Sub ManageRulesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ManageRulesToolStripMenuItem.Click
        Me.Hide()
        ManageRuleEngine.Show()
    End Sub
    Private Sub ViewProfileDataToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ViewProfileDataToolStripMenuItem.Click
        Me.Hide()
        ViewSuppliers.Show()
    End Sub
    Private Sub Back_Click(sender As Object, e As EventArgs) Handles Back.Click
        Dim vbAns = MsgBox("Are you sure you want to close Sirion Lab's Yes-Supply?", vbYesNo + vbInformation, "Yes-Supply: Confirmation")
        If vbAns = vbYes Then
            Me.Close()
        Else
            'Do Nothiong
        End If
    End Sub

    Private Sub ApplyRuleEngineToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ApplyRuleEngineToolStripMenuItem.Click
        Me.Hide()
        ApplyRule.Show()
    End Sub

    Private Sub DeployAlgorithmToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DeployAlgorithmToolStripMenuItem.Click
        Me.Hide()
        DeployModel.Show()
    End Sub

    Private Sub ApplyAlgorithmToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ApplyAlgorithmToolStripMenuItem.Click
        Me.Hide()
        ApplyModel.Show()
    End Sub

    Private Sub ManageCSVProfileToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ManageCSVProfileToolStripMenuItem.Click
        Me.Hide()
        NewProfile.Show()
    End Sub

    Private Sub ProfileDescribeToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ProfileDescribeToolStripMenuItem.Click
        Me.Hide()
        ProfileDescribe.Show()
    End Sub
    Private Sub YSMainMenu_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim csvProfiles As String = ""
        Dim fs2 As New FileStream(Common.SLPATH_CONST & Common.SLPROFILES_PATH, FileMode.Open, FileAccess.Read)
        xmlTrProfdoc.Load(fs2)
        xmlnode = xmlTrProfdoc.GetElementsByTagName("csvprofile_name")
        For i = 0 To xmlnode.Count - 1
            xmlnode = xmlTrProfdoc.GetElementsByTagName("csvprofile_name")
            csvProfiles = csvProfiles & xmlnode(i).ChildNodes.Item(0).InnerText.Trim() & ","
            xmlnode = xmlTrProfdoc.GetElementsByTagName("csvprofile_path")
            csvProfiles = csvProfiles & xmlnode(i).ChildNodes.Item(0).InnerText.Trim() & ","
            xmlnode = xmlTrProfdoc.GetElementsByTagName("csvfile_name")
            csvProfiles = csvProfiles & xmlnode(i).ChildNodes.Item(0).InnerText.Trim() & ""
            Dim SplitLine = Split(csvProfiles, ",")
            DGV_Profiles.Rows.Add(SplitLine)
            csvProfiles = ""
        Next

        Dim csvRules As String = ""
        Dim fs3 As New FileStream(Common.SLPATH_CONST & Common.SLRULES_PATH, FileMode.Open, FileAccess.Read)
        xmlRuledoc.Load(fs3)
        xmlnode = xmlRuledoc.GetElementsByTagName("rule_name")
        For i = 0 To xmlnode.Count - 1
            xmlnode = xmlRuledoc.GetElementsByTagName("rule_name")
            csvRules = csvRules & xmlnode(i).ChildNodes.Item(0).InnerText.Trim() & ","
            xmlnode = xmlRuledoc.GetElementsByTagName("rules")
            csvRules = csvRules & xmlnode(i).ChildNodes.Item(0).InnerText.Trim() & ","
            Dim SplitLine = Split(csvRules, ",")
            DGV_Rules.Rows.Add(SplitLine)
            csvRules = ""
        Next

        Dim csvModels As String = ""
        Dim fs4 As New FileStream(Common.SLPATH_CONST & Common.SLMODELS_PATH, FileMode.Open, FileAccess.Read)
        xmlModeldoc.Load(fs4)
        xmlnode = xmlModeldoc.GetElementsByTagName("model_name")
        For i = 0 To xmlnode.Count - 1
            xmlnode = xmlModeldoc.GetElementsByTagName("model_name")
            csvModels = csvModels & xmlnode(i).ChildNodes.Item(0).InnerText.Trim() & ","
            xmlnode = xmlModeldoc.GetElementsByTagName("tr_profile")
            csvModels = csvModels & xmlnode(i).ChildNodes.Item(0).InnerText.Trim() & ","
            xmlnode = xmlModeldoc.GetElementsByTagName("tst_profile")
            csvModels = csvModels & xmlnode(i).ChildNodes.Item(0).InnerText.Trim() & ","
            xmlnode = xmlModeldoc.GetElementsByTagName("tst_datasize")
            csvModels = csvModels & xmlnode(i).ChildNodes.Item(0).InnerText.Trim() & ","
            xmlnode = xmlModeldoc.GetElementsByTagName("algo")
            csvModels = csvModels & xmlnode(i).ChildNodes.Item(0).InnerText.Trim() & ","
            Dim SplitLine = Split(csvModels, ",")
            DGV_Model.Rows.Add(SplitLine)
            csvModels = ""
        Next
    End Sub
    Private Sub ManageSupplierToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ManageSupplierToolStripMenuItem.Click
        MsgBox("This feature will be available in next version.", vbInformation, "Yes-Supply Information")
    End Sub

    Private Sub MergeProfilesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MergeProfilesToolStripMenuItem.Click
        MsgBox("This feature will be available in next version.", vbInformation, "Yes-Supply Information")
    End Sub
End Class
