﻿Imports System.IO
Public Class NewProfile
    Dim XMLObject As New XMLManager()
    Dim common As New Common
    Private Sub Save_Click(sender As Object, e As EventArgs) Handles Save.Click
        Dim directory As String = Common.SLPATH_CONST
        Dim filePath As String = directory & Common.SLPROFILES_PATH
        If Not System.IO.Directory.Exists(directory) Then
            System.IO.Directory.CreateDirectory(directory)
        End If
        If Not System.IO.File.Exists(filePath) Then
            System.IO.File.Create(filePath).Dispose()
        End If
        Dim vbAns = MsgBox("Are you sure you want to add new record for profile?", vbQuestion & vbYesNo, "YesSupply: Confirmation")
        If vbAns = vbYes Then
            XMLObject.InsertNewNode(filePath,
            ProfileName.Text, CSVPath.Text, CSVFIleName.Text)
            common.ShowConfirmation("profile")
        Else
            'Do Nothing
        End If
        Profiles.Items.Clear()
        common.FillCommonCombos(Profiles, Common.SLPROFILES_PATH, "csvprofile_name")
    End Sub

    Private Sub CSVPath_Click(sender As Object, e As EventArgs) Handles CSVPath.Click
        OFDProfile.ShowDialog()
        CSVPath.Text = OFDProfile.FileName
        CSVFIleName.Text = Path.GetFileName(CSVPath.Text)
    End Sub
    Private Sub NewProfile_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        common.FillCommonCombos(Profiles, Common.SLPROFILES_PATH, "csvprofile_name")
    End Sub
    Private Sub Back_Click(sender As Object, e As EventArgs) Handles Back.Click
        Me.Close()
        YSMainMenu.Show()
    End Sub

    Private Sub DeleteProfile_Click(sender As Object, e As EventArgs) Handles DeleteProfile.Click

        Dim vbAns = MsgBox("Are you sure you want to delete this profile. This is irreversible operation.", vbYesNo + vbInformation, "YesSupply: Confirmation")
        If vbAns = vbYes Then
            XMLObject.RemoveProfileXMLNode(Profiles.SelectedItem)
            common.ShowConfirmation("profile")
        Else
            'Do nothing
        End If

    End Sub
End Class