﻿Imports System.IO
Imports System.Xml
Public Class ApplyModel
    Dim xmldoc As New XmlDataDocument()
    Dim xmlTrProfdoc As New XmlDataDocument()
    Dim xmlTsProfdoc As New XmlDataDocument()
    Dim xmlnode As XmlNodeList
    Dim common As New Common
    Private Sub Back_Click(sender As Object, e As EventArgs) Handles Back.Click
        Me.Hide()
        YSMainMenu.Show()
    End Sub

    Private Sub ApplyModel_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        common.FillCommonCombos(ModelName, Common.SLMODELS_PATH, "model_name")
    End Sub

    Private Sub AppMdl_Click(sender As Object, e As EventArgs) Handles AppMdl.Click
        Dim SelectedModel As String = "", SelectedModelName As String = ""
        Dim TRProfie As String = "", TSProfile As String = "", TSDataSize As String = ""
        Dim SelModelName As String = ModelName.SelectedItem.ToString

        Dim fs As New FileStream(Common.SLPATH_CONST & Common.SLMODELS_PATH, FileMode.Open, FileAccess.Read)
        xmldoc.Load(fs)
        xmlnode = xmldoc.GetElementsByTagName("model_name")
        For i = 0 To xmlnode.Count - 1
            SelectedModel = xmlnode(i).ChildNodes.Item(0).InnerText.Trim()
            If SelectedModel = SelModelName Then
                xmlnode = xmldoc.GetElementsByTagName("algo")
                SelectedModelName = xmlnode(i).ChildNodes.Item(0).InnerText.Trim()
                xmlnode = xmldoc.GetElementsByTagName("tr_profile")
                TRProfie = xmlnode(i).ChildNodes.Item(0).InnerText.Trim()
                xmlnode = xmldoc.GetElementsByTagName("tst_profile")
                TSProfile = xmlnode(i).ChildNodes.Item(0).InnerText.Trim()
                xmlnode = xmldoc.GetElementsByTagName("tst_datasize")
                TSDataSize = xmlnode(i).ChildNodes.Item(0).InnerText.Trim()
                Exit For
            End If
        Next
        fs.Close()

        Dim fs2 As New FileStream(Common.SLPATH_CONST & Common.SLPROFILES_PATH, FileMode.Open, FileAccess.Read)
        xmlTrProfdoc.Load(fs2)
        xmlnode = xmlTrProfdoc.GetElementsByTagName("csvprofile_name")
        Dim TrainingProfileName = TRProfie.ToString
        Dim TrainingProfilePath As String = ""
        For i = 0 To xmlnode.Count - 1
            SelectedModel = xmlnode(i).ChildNodes.Item(0).InnerText.Trim()
            If SelectedModel = TrainingProfileName Then
                xmlnode = xmlTrProfdoc.GetElementsByTagName("csvprofile_path")
                TrainingProfilePath = xmlnode(i).ChildNodes.Item(0).InnerText.Trim()
                Exit For
            End If
        Next

        Dim fs3 As New FileStream(Common.SLPATH_CONST & Common.SLPROFILES_PATH, FileMode.Open, FileAccess.Read)
        xmlTsProfdoc.Load(fs3)
        xmlnode = xmlTsProfdoc.GetElementsByTagName("csvprofile_name")
        Dim TestProfileName = TSProfile.ToString
        Dim TestProfilePath As String = ""
        For i = 0 To xmlnode.Count - 1
            SelectedModel = xmlnode(i).ChildNodes.Item(0).InnerText.Trim()
            If SelectedModel = TestProfileName Then
                xmlnode = xmlTsProfdoc.GetElementsByTagName("csvprofile_path")
                TestProfilePath = xmlnode(i).ChildNodes.Item(0).InnerText.Trim()
                Exit For
            End If
        Next

        Dim TemplatePath As String = Common.SLPATH_CONST & "pythonTemplates\data_science_logistic.py"
        Dim FilePath As String
        FilePath = "C:\slys\data_science_logistic.py"

        My.Computer.FileSystem.CopyFile(TemplatePath, FilePath,
                        Microsoft.VisualBasic.FileIO.UIOption.OnlyErrorDialogs,
                        Microsoft.VisualBasic.FileIO.UICancelOption.DoNothing)
        Dim ExtractPath As String = Common.SLPATH_CONST & "extracts\"

        ExtractPath = ExtractPath & "extract_models_" & Path.GetFileName(TestProfilePath)
        IO.File.WriteAllText(FilePath, IO.File.ReadAllText(FilePath).Replace("#TRAINING_PROFILE_PATH#", TrainingProfilePath))
        IO.File.WriteAllText(FilePath, IO.File.ReadAllText(FilePath).Replace("#TEST_PROFILE_PATH#", TestProfilePath))
        IO.File.WriteAllText(FilePath, IO.File.ReadAllText(FilePath).Replace("$TESTSIZE$", TSDataSize))

        Dim extractionLine As String = vbCrLf & "merged.to_csv(r'" & ExtractPath & "' , index=False)"
        My.Computer.FileSystem.WriteAllText(FilePath, extractionLine, True)

        Shell("python " & Common.SLPATH_CONST & "\data_science_logistic.py")


        DGV.Rows.Clear()
        Dim fName As String = ExtractPath
        Dim TextLine As String = ""
        Dim SplitLine() As String
        Dim Count As Integer = 0
        If System.IO.File.Exists(fName) = True Then
            Using objReader As New System.IO.StreamReader(fName)
                Do While objReader.Peek() <> -1
                    TextLine = objReader.ReadLine()
                    TextLine = objReader.ReadLine()
                    SplitLine = Split(TextLine, ",")
                    DGV.Rows.Add(SplitLine)
                    Count += 1
                Loop
            End Using
        Else
            MsgBox("ERROR: File Does Not Exist")
        End If


    End Sub
End Class