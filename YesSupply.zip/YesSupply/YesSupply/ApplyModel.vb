﻿Imports System.IO
Imports System.Xml
Public Class ApplyModel
    Dim xmldoc As New XmlDataDocument()
    Dim xmlTrProfdoc As New XmlDataDocument()
    Dim xmlTsProfdoc As New XmlDataDocument()
    Dim xmlnode As XmlNodeList
    Dim common As New Common
    Dim ExtractPath As String = ""
    Private Sub Back_Click(sender As Object, e As EventArgs) Handles Back.Click
        Me.Close()
        YSMainMenu.Show()
    End Sub
    Private Sub ApplyModel_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        common.FillCommonCombos(ModelName, Common.SLMODELS_PATH, "model_name")
        SelectedCriteria.Enabled = False
        SelectedCriteria.SelectedIndex = 0
        ExportExcel.Enabled = False
    End Sub
    Private Sub AppMdl_Click(sender As Object, e As EventArgs) Handles AppMdl.Click
        Dim SelectedModel As String = "", SelectedModelName As String = ""
        Dim TRProfie As String = "", TSProfile As String = "", TSDataSize As String = ""
        Dim SelModelName As String = ModelName.SelectedItem.ToString

        If common.ShowBlankSelectionErrorMessage(ModelName, "Model Name") Then
            Exit Sub
        End If

        Dim fs As New FileStream(Common.SLPATH_CONST & Common.SLMODELS_PATH, FileMode.Open, FileAccess.Read)
        xmldoc.Load(fs)
        xmlnode = xmldoc.GetElementsByTagName("model_name")
        For i = 0 To xmlnode.Count - 1
            SelectedModel = xmlnode(i).ChildNodes.Item(0).InnerText.Trim()
            If SelectedModel = SelModelName Then
                xmlnode = xmldoc.GetElementsByTagName("algo")
                SelectedModelName = xmlnode(i).ChildNodes.Item(0).InnerText.Trim()
                xmlnode = xmldoc.GetElementsByTagName("tr_profile")
                TRProfie = xmlnode(i).ChildNodes.Item(0).InnerText.Trim()
                xmlnode = xmldoc.GetElementsByTagName("tst_profile")
                TSProfile = xmlnode(i).ChildNodes.Item(0).InnerText.Trim()
                xmlnode = xmldoc.GetElementsByTagName("tst_datasize")
                TSDataSize = xmlnode(i).ChildNodes.Item(0).InnerText.Trim()
                Exit For
            End If
        Next
        fs.Close()

        Dim fs2 As New FileStream(Common.SLPATH_CONST & Common.SLPROFILES_PATH, FileMode.Open, FileAccess.Read)
        xmlTrProfdoc.Load(fs2)
        xmlnode = xmlTrProfdoc.GetElementsByTagName("csvprofile_name")
        Dim TrainingProfileName = TRProfie.ToString
        Dim TrainingProfilePath As String = ""
        For i = 0 To xmlnode.Count - 1
            SelectedModel = xmlnode(i).ChildNodes.Item(0).InnerText.Trim()
            If SelectedModel = TrainingProfileName Then
                xmlnode = xmlTrProfdoc.GetElementsByTagName("csvprofile_path")
                TrainingProfilePath = xmlnode(i).ChildNodes.Item(0).InnerText.Trim()
                Exit For
            End If
        Next

        Dim fs3 As New FileStream(Common.SLPATH_CONST & Common.SLPROFILES_PATH, FileMode.Open, FileAccess.Read)
        xmlTsProfdoc.Load(fs3)
        xmlnode = xmlTsProfdoc.GetElementsByTagName("csvprofile_name")
        Dim TestProfileName = TSProfile.ToString
        Dim TestProfilePath As String = ""
        For i = 0 To xmlnode.Count - 1
            SelectedModel = xmlnode(i).ChildNodes.Item(0).InnerText.Trim()
            If SelectedModel = TestProfileName Then
                xmlnode = xmlTsProfdoc.GetElementsByTagName("csvprofile_path")
                TestProfilePath = xmlnode(i).ChildNodes.Item(0).InnerText.Trim()
                Exit For
            End If
        Next

        If SelectedModelName = "Logistic Regression" Then
            Dim TemplatePath As String = Common.SLPATH_CONST & "pythonTemplates\data_science_logistic.py"
            Dim FilePath As String
            FilePath = "C:\slys\data_science_logistic.py"

            My.Computer.FileSystem.CopyFile(TemplatePath, FilePath,
                            Microsoft.VisualBasic.FileIO.UIOption.OnlyErrorDialogs,
                            Microsoft.VisualBasic.FileIO.UICancelOption.DoNothing)
            ExtractPath = Common.SLPATH_CONST & "extracts\"

            ExtractPath = ExtractPath & "extract_models_" & Path.GetFileName(TestProfilePath)
            IO.File.WriteAllText(FilePath, IO.File.ReadAllText(FilePath).Replace("#TRAINING_PROFILE_PATH#", TrainingProfilePath))
            IO.File.WriteAllText(FilePath, IO.File.ReadAllText(FilePath).Replace("#TEST_PROFILE_PATH#", TestProfilePath))
            IO.File.WriteAllText(FilePath, IO.File.ReadAllText(FilePath).Replace("$TESTSIZE$", TSDataSize))

            Dim extractionLine As String = vbCrLf & "merged.to_csv(r'" & ExtractPath & "' , index=False)"
            My.Computer.FileSystem.WriteAllText(FilePath, extractionLine, True)

            Shell("python " & Common.SLPATH_CONST & "\data_science_logistic.py")
        ElseIf SelectedModelName = "LogIT (Stats Model)" Then
            'MsgBox("This model will be available in the next version.", vbInformation, "Yes-Supply: Information")
            Dim TemplatePath As String = Common.SLPATH_CONST & "pythonTemplates\data_science_logIT.py"
            Dim FilePath As String
            FilePath = "C:\slys\data_science_logIT.py"

            My.Computer.FileSystem.CopyFile(TemplatePath, FilePath,
                            Microsoft.VisualBasic.FileIO.UIOption.OnlyErrorDialogs,
                            Microsoft.VisualBasic.FileIO.UICancelOption.DoNothing)
            ExtractPath = Common.SLPATH_CONST & "extracts\"

            ExtractPath = ExtractPath & "extract_models_" & Path.GetFileName(TestProfilePath)
            IO.File.WriteAllText(FilePath, IO.File.ReadAllText(FilePath).Replace("#TRAINING_PROFILE_PATH#", TrainingProfilePath))
            IO.File.WriteAllText(FilePath, IO.File.ReadAllText(FilePath).Replace("#TEST_PROFILE_PATH#", TestProfilePath))
            Dim extractionLine As String = vbCrLf & "merged.to_csv(r'" & ExtractPath & "' , index=False)"
            My.Computer.FileSystem.WriteAllText(FilePath, extractionLine, True)

            Shell("python " & Common.SLPATH_CONST & "\data_science_logIT.py")

        ElseIf SelectedModelName = "Neural Netword based" Then
            MsgBox("This model will be available in the next version.", vbInformation, "Yes-Supply: Information")
        End If

        DGV.Rows.Clear()
        Dim fName As String = ExtractPath
        Dim TextLine As String = ""
        Dim SplitLine() As String
        Dim Count As Integer = 0
        If System.IO.File.Exists(fName) = True Then
            Using objReader As New System.IO.StreamReader(fName)
                Do While objReader.Peek() <> -1
                    TextLine = objReader.ReadLine()
                    TextLine = objReader.ReadLine()

                    SplitLine = Split(TextLine, ",")
                    If UBound(SplitLine) = 1 Then
                        If SplitLine(1) = "Y" Then
                            DGV.Rows.Add(SplitLine)
                            Count += 1
                        End If
                    End If

                Loop
            End Using
        Else
            MsgBox("ERROR: File Does Not Exist")
        End If
        If DGV.Rows.Count < 1 Then
            SelectedCriteria.Enabled = False
            ExportExcel.Enabled = False
        Else
            SelectedCriteria.Enabled = True
            ExportExcel.Enabled = True
        End If
        xmldoc.DocumentElement.ParentNode.RemoveAll()
        xmlTrProfdoc.DocumentElement.ParentNode.RemoveAll()
        xmlTsProfdoc.DocumentElement.ParentNode.RemoveAll()
        fs2.Close()
        fs.Close()
        fs3.Close()
    End Sub

    Private Sub SelectedCriteria_SelectedIndexChanged(sender As Object, e As EventArgs) Handles SelectedCriteria.SelectedIndexChanged
        If SelectedCriteria.Text = "Top 10 Only" Then
            DGV.Rows.Clear()
            Dim fName As String = ExtractPath
            Dim TextLine As String = ""
            Dim SplitLine() As String
            Dim Count As Integer = 0
            If System.IO.File.Exists(fName) = True Then
                Using objReader As New System.IO.StreamReader(fName)
                    Do While objReader.Peek() <> -1
                        If Count <= 10 Then
                            TextLine = objReader.ReadLine()
                            TextLine = objReader.ReadLine()
                            SplitLine = Split(TextLine, ",")
                            DGV.Rows.Add(SplitLine)
                            Count += 1
                        Else
                            Exit Do
                        End If
                    Loop
                End Using
            Else
                MsgBox("ERROR: File Does Not Exist")
            End If
        ElseIf SelectedCriteria.Text = "Top 50 Only" Then
            DGV.Rows.Clear()
            Dim fName As String = ExtractPath
            Dim TextLine As String = ""
            Dim SplitLine() As String
            Dim Count As Integer = 0
            If System.IO.File.Exists(fName) = True Then
                Using objReader As New System.IO.StreamReader(fName)
                    Do While objReader.Peek() <> -1
                        If Count <= 50 Then
                            TextLine = objReader.ReadLine()
                            TextLine = objReader.ReadLine()
                            SplitLine = Split(TextLine, ",")
                            DGV.Rows.Add(SplitLine)
                            Count += 1
                        Else
                            Exit Do
                        End If
                    Loop
                End Using
            Else
                MsgBox("ERROR: File Does Not Exist")
            End If
        ElseIf SelectedCriteria.Text = "Top 100 Only" Then
            DGV.Rows.Clear()
            Dim fName As String = ExtractPath
            Dim TextLine As String = ""
            Dim SplitLine() As String
            Dim Count As Integer = 0
            If System.IO.File.Exists(fName) = True Then
                Using objReader As New System.IO.StreamReader(fName)
                    Do While objReader.Peek() <> -1
                        If Count <= 100 Then
                            TextLine = objReader.ReadLine()
                            TextLine = objReader.ReadLine()
                            SplitLine = Split(TextLine, ",")
                            DGV.Rows.Add(SplitLine)
                            Count += 1
                        Else
                            Exit Do
                        End If
                    Loop
                End Using
            Else
                MsgBox("ERROR: File Does Not Exist")
            End If
        End If
    End Sub

    Private Sub ExportExcel_Click(sender As Object, e As EventArgs) Handles ExportExcel.Click
        MsgBox("This feature will be available in the next version.", vbInformation, "Yes-Supply: Information")
    End Sub
End Class