﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class NewProfile
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(NewProfile))
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PBLogo = New System.Windows.Forms.PictureBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.ProfileName = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.CSVPath = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Save = New System.Windows.Forms.Button()
        Me.CSVFIleName = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.OFDProfile = New System.Windows.Forms.OpenFileDialog()
        Me.Back = New System.Windows.Forms.Button()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.DeleteProfile = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Profiles = New System.Windows.Forms.ComboBox()
        Me.GroupBox1.SuspendLayout()
        CType(Me.PBLogo, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.GroupBox1.Location = New System.Drawing.Point(118, 20)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.GroupBox1.Size = New System.Drawing.Size(639, 74)
        Me.GroupBox1.TabIndex = 5
        Me.GroupBox1.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Bookman Old Style", 22.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label1.ForeColor = System.Drawing.Color.ForestGreen
        Me.Label1.Location = New System.Drawing.Point(10, 21)
        Me.Label1.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(410, 44)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Manage CSV Profiles"
        '
        'PBLogo
        '
        Me.PBLogo.Image = CType(resources.GetObject("PBLogo.Image"), System.Drawing.Image)
        Me.PBLogo.Location = New System.Drawing.Point(14, 12)
        Me.PBLogo.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.PBLogo.Name = "PBLogo"
        Me.PBLogo.Size = New System.Drawing.Size(100, 100)
        Me.PBLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PBLogo.TabIndex = 4
        Me.PBLogo.TabStop = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label2.ForeColor = System.Drawing.Color.ForestGreen
        Me.Label2.Location = New System.Drawing.Point(52, 130)
        Me.Label2.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(145, 23)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Profile Name :"
        '
        'ProfileName
        '
        Me.ProfileName.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.ProfileName.Location = New System.Drawing.Point(207, 125)
        Me.ProfileName.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.ProfileName.Name = "ProfileName"
        Me.ProfileName.Size = New System.Drawing.Size(556, 30)
        Me.ProfileName.TabIndex = 12
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label3.ForeColor = System.Drawing.Color.ForestGreen
        Me.Label3.Location = New System.Drawing.Point(82, 183)
        Me.Label3.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(115, 23)
        Me.Label3.TabIndex = 13
        Me.Label3.Text = "CSV Path :"
        '
        'CSVPath
        '
        Me.CSVPath.Font = New System.Drawing.Font("Bookman Old Style", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.CSVPath.Location = New System.Drawing.Point(207, 177)
        Me.CSVPath.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.CSVPath.Name = "CSVPath"
        Me.CSVPath.ReadOnly = True
        Me.CSVPath.Size = New System.Drawing.Size(556, 34)
        Me.CSVPath.TabIndex = 14
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label4.ForeColor = System.Drawing.Color.ForestGreen
        Me.Label4.Location = New System.Drawing.Point(207, 214)
        Me.Label4.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(254, 23)
        Me.Label4.TabIndex = 15
        Me.Label4.Text = "Click to open folder view."
        '
        'Save
        '
        Me.Save.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Save.Location = New System.Drawing.Point(118, 297)
        Me.Save.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.Save.Name = "Save"
        Me.Save.Size = New System.Drawing.Size(139, 40)
        Me.Save.TabIndex = 28
        Me.Save.Text = "&Save Profile"
        Me.Save.UseVisualStyleBackColor = True
        '
        'CSVFIleName
        '
        Me.CSVFIleName.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.CSVFIleName.Location = New System.Drawing.Point(207, 242)
        Me.CSVFIleName.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.CSVFIleName.Name = "CSVFIleName"
        Me.CSVFIleName.ReadOnly = True
        Me.CSVFIleName.Size = New System.Drawing.Size(556, 30)
        Me.CSVFIleName.TabIndex = 30
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label5.ForeColor = System.Drawing.Color.ForestGreen
        Me.Label5.Location = New System.Drawing.Point(29, 242)
        Me.Label5.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(168, 23)
        Me.Label5.TabIndex = 31
        Me.Label5.Text = "CSV File Name :"
        '
        'OFDProfile
        '
        Me.OFDProfile.FileName = "OFD"
        '
        'Back
        '
        Me.Back.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Back.Location = New System.Drawing.Point(13, 297)
        Me.Back.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Back.Name = "Back"
        Me.Back.Size = New System.Drawing.Size(96, 40)
        Me.Back.TabIndex = 39
        Me.Back.Text = "< &Back"
        Me.Back.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.DeleteProfile)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.Profiles)
        Me.GroupBox2.Location = New System.Drawing.Point(14, 355)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(743, 91)
        Me.GroupBox2.TabIndex = 40
        Me.GroupBox2.TabStop = False
        '
        'DeleteProfile
        '
        Me.DeleteProfile.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.DeleteProfile.Location = New System.Drawing.Point(582, 28)
        Me.DeleteProfile.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.DeleteProfile.Name = "DeleteProfile"
        Me.DeleteProfile.Size = New System.Drawing.Size(153, 40)
        Me.DeleteProfile.TabIndex = 41
        Me.DeleteProfile.Text = "&Delete Profile"
        Me.DeleteProfile.UseVisualStyleBackColor = True
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label6.ForeColor = System.Drawing.Color.ForestGreen
        Me.Label6.Location = New System.Drawing.Point(18, 33)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(145, 23)
        Me.Label6.TabIndex = 43
        Me.Label6.Text = "Profile Name :"
        '
        'Profiles
        '
        Me.Profiles.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Profiles.FormattingEnabled = True
        Me.Profiles.Location = New System.Drawing.Point(171, 30)
        Me.Profiles.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Profiles.Name = "Profiles"
        Me.Profiles.Size = New System.Drawing.Size(402, 31)
        Me.Profiles.TabIndex = 42
        '
        'NewProfile
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(13.0!, 23.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(773, 456)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.Back)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.CSVFIleName)
        Me.Controls.Add(Me.Save)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.CSVPath)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.ProfileName)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.PBLogo)
        Me.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.MaximizeBox = False
        Me.Name = "NewProfile"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Yes-Supply : Manage CSV Profiles"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.PBLogo, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Label1 As Label
    Friend WithEvents PBLogo As PictureBox
    Friend WithEvents Label2 As Label
    Friend WithEvents ProfileName As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents CSVPath As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Save As Button
    Friend WithEvents CSVFIleName As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents OFDProfile As OpenFileDialog
    Friend WithEvents Back As Button
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents DeleteProfile As Button
    Friend WithEvents Label6 As Label
    Friend WithEvents Profiles As ComboBox
End Class
