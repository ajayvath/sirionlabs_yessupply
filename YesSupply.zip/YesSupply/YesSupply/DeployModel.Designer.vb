﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class DeployModel
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(DeployModel))
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PBLogo = New System.Windows.Forms.PictureBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TrainingDataPName = New System.Windows.Forms.ComboBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TestDataPName = New System.Windows.Forms.ComboBox()
        Me.TestDataSize = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.ModelName = New System.Windows.Forms.TextBox()
        Me.Algorithm = New System.Windows.Forms.ComboBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Back = New System.Windows.Forms.Button()
        Me.SaveModel = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        CType(Me.PBLogo, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.ForeColor = System.Drawing.SystemColors.ControlLight
        Me.GroupBox1.Location = New System.Drawing.Point(121, 27)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(8, 3, 8, 3)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(8, 3, 8, 3)
        Me.GroupBox1.Size = New System.Drawing.Size(842, 67)
        Me.GroupBox1.TabIndex = 7
        Me.GroupBox1.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Bookman Old Style", 22.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label1.ForeColor = System.Drawing.Color.ForestGreen
        Me.Label1.Location = New System.Drawing.Point(16, 14)
        Me.Label1.Margin = New System.Windows.Forms.Padding(8, 0, 8, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(566, 44)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Data Science : Deploy Model"
        '
        'PBLogo
        '
        Me.PBLogo.Image = CType(resources.GetObject("PBLogo.Image"), System.Drawing.Image)
        Me.PBLogo.Location = New System.Drawing.Point(10, 12)
        Me.PBLogo.Margin = New System.Windows.Forms.Padding(8, 3, 8, 3)
        Me.PBLogo.Name = "PBLogo"
        Me.PBLogo.Size = New System.Drawing.Size(100, 100)
        Me.PBLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PBLogo.TabIndex = 6
        Me.PBLogo.TabStop = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label2.ForeColor = System.Drawing.Color.ForestGreen
        Me.Label2.Location = New System.Drawing.Point(25, 186)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(287, 23)
        Me.Label2.TabIndex = 36
        Me.Label2.Text = "Training Data Profile Name :"
        '
        'TrainingDataPName
        '
        Me.TrainingDataPName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.TrainingDataPName.FormattingEnabled = True
        Me.TrainingDataPName.Location = New System.Drawing.Point(309, 178)
        Me.TrainingDataPName.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.TrainingDataPName.Name = "TrainingDataPName"
        Me.TrainingDataPName.Size = New System.Drawing.Size(396, 31)
        Me.TrainingDataPName.TabIndex = 35
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label3.ForeColor = System.Drawing.Color.ForestGreen
        Me.Label3.Location = New System.Drawing.Point(43, 234)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(269, 23)
        Me.Label3.TabIndex = 37
        Me.Label3.Text = "Actual Data Profile Name :"
        '
        'TestDataPName
        '
        Me.TestDataPName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.TestDataPName.FormattingEnabled = True
        Me.TestDataPName.Location = New System.Drawing.Point(309, 226)
        Me.TestDataPName.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.TestDataPName.Name = "TestDataPName"
        Me.TestDataPName.Size = New System.Drawing.Size(396, 31)
        Me.TestDataPName.TabIndex = 38
        '
        'TestDataSize
        '
        Me.TestDataSize.Location = New System.Drawing.Point(863, 186)
        Me.TestDataSize.Name = "TestDataSize"
        Me.TestDataSize.Size = New System.Drawing.Size(100, 31)
        Me.TestDataSize.TabIndex = 39
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label4.ForeColor = System.Drawing.Color.ForestGreen
        Me.Label4.Location = New System.Drawing.Point(713, 175)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(163, 46)
        Me.Label4.TabIndex = 40
        Me.Label4.Text = "Test Data Size. " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "(Format 0.x)"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label5.ForeColor = System.Drawing.Color.ForestGreen
        Me.Label5.Location = New System.Drawing.Point(30, 134)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(282, 23)
        Me.Label5.TabIndex = 41
        Me.Label5.Text = "Data Science Model Name : "
        '
        'ModelName
        '
        Me.ModelName.Location = New System.Drawing.Point(310, 131)
        Me.ModelName.Name = "ModelName"
        Me.ModelName.Size = New System.Drawing.Size(396, 31)
        Me.ModelName.TabIndex = 42
        '
        'Algorithm
        '
        Me.Algorithm.AutoCompleteCustomSource.AddRange(New String() {"Logistic Regression", "LogIT (Stats Model)", "Neural Netword based"})
        Me.Algorithm.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Algorithm.FormattingEnabled = True
        Me.Algorithm.Items.AddRange(New Object() {"Logistic Regression", "LogIT (Stats Model)", "Neural Netword based"})
        Me.Algorithm.Location = New System.Drawing.Point(310, 279)
        Me.Algorithm.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Algorithm.Name = "Algorithm"
        Me.Algorithm.Size = New System.Drawing.Size(396, 31)
        Me.Algorithm.TabIndex = 44
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label6.ForeColor = System.Drawing.Color.ForestGreen
        Me.Label6.Location = New System.Drawing.Point(54, 287)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(258, 23)
        Me.Label6.TabIndex = 43
        Me.Label6.Text = "Data Science Alogrithm : "
        '
        'Back
        '
        Me.Back.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Back.Location = New System.Drawing.Point(16, 352)
        Me.Back.Name = "Back"
        Me.Back.Size = New System.Drawing.Size(96, 40)
        Me.Back.TabIndex = 46
        Me.Back.Text = "< &Back"
        Me.Back.UseVisualStyleBackColor = True
        '
        'SaveModel
        '
        Me.SaveModel.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.SaveModel.Location = New System.Drawing.Point(121, 352)
        Me.SaveModel.Name = "SaveModel"
        Me.SaveModel.Size = New System.Drawing.Size(139, 40)
        Me.SaveModel.TabIndex = 45
        Me.SaveModel.Text = "Save &Model"
        Me.SaveModel.UseVisualStyleBackColor = True
        '
        'DeployModel
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(13.0!, 23.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(975, 402)
        Me.Controls.Add(Me.Back)
        Me.Controls.Add(Me.SaveModel)
        Me.Controls.Add(Me.Algorithm)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.ModelName)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.TestDataSize)
        Me.Controls.Add(Me.TestDataPName)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.TrainingDataPName)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.PBLogo)
        Me.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.MaximizeBox = False
        Me.Name = "DeployModel"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "DeployModel"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.PBLogo, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Label1 As Label
    Friend WithEvents PBLogo As PictureBox
    Friend WithEvents Label2 As Label
    Friend WithEvents TrainingDataPName As ComboBox
    Friend WithEvents Label3 As Label
    Friend WithEvents TestDataPName As ComboBox
    Friend WithEvents TestDataSize As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents ModelName As TextBox
    Friend WithEvents Algorithm As ComboBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Back As Button
    Friend WithEvents SaveModel As Button
End Class
