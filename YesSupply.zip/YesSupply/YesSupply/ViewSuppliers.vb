﻿Imports System.IO
Imports System.Xml
Public Class ViewSuppliers
    Dim xmldoc As New XmlDataDocument()
    Dim xmlnode As XmlNodeList
    Dim common As New Common
    Private Sub Back_Click(sender As Object, e As EventArgs) Handles Back.Click
        Me.Close()
        YSMainMenu.Show()

    End Sub
    Private Sub ViewSuppliers_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        common.FillCommonCombos(ProfileName, Common.SLPROFILES_PATH, "csvprofile_name")
        Dim fs As New FileStream(Common.SLPATH_CONST & Common.SLPROFILES_PATH, FileMode.Open, FileAccess.Read)
        xmldoc.Load(fs)
    End Sub
    Private Sub ProfileName_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ProfileName.SelectedIndexChanged
        DGV.Rows.Clear()
        Dim SelectedProfile As String = ""
        Dim SelectedProfilePath As String = ""
        Dim SelProfileName As String = ProfileName.SelectedItem.ToString
        If ProfileName.SelectedIndex = 0 Then
            Exit Sub
        End If

        Dim i As Integer
        xmlnode = xmldoc.GetElementsByTagName("csvprofile_name")
        For i = 0 To xmlnode.Count - 1
            SelectedProfile = xmlnode(i).ChildNodes.Item(0).InnerText.Trim()
            If SelectedProfile = SelProfileName Then
                xmlnode = xmldoc.GetElementsByTagName("csvprofile_path")
                SelectedProfilePath = xmlnode(i).ChildNodes.Item(0).InnerText.Trim()
            End If
        Next
        ProfileName.SelectedIndex = 0

        Dim fName As String = SelectedProfilePath
        Dim TextLine As String = ""
        Dim SplitLine() As String
        Dim Count As Integer = 0
        If System.IO.File.Exists(fName) = True Then
            Using objReader As New System.IO.StreamReader(fName)
                Do While objReader.Peek() <> -1
                    TextLine = objReader.ReadLine()
                    TextLine = objReader.ReadLine()
                    SplitLine = Split(TextLine, ",")
                    DGV.Rows.Add(SplitLine)
                    Count += 1
                Loop
            End Using
        Else
            MsgBox("ERROR: File Does Not Exist")
        End If
        RecCount.Text = DGV.Rows.Count & " records."
        'common.ShowInGrid(DGV, RecCount, SelectedProfilePath)

    End Sub
End Class