﻿Imports System.Xml
Imports System.IO
Public Class ProfileDescribe
    Dim xmldoc As New XmlDataDocument()
    Dim xmlnode As XmlNodeList
    Dim common As New Common
    Private Sub ProfuileDescribe_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        common.FillCommonCombos(ProfileName, Common.SLPROFILES_PATH, "csvprofile_name")
    End Sub

    Private Sub ViewData_Click(sender As Object, e As EventArgs) Handles ViewData.Click

        Dim FilePath As String
        Dim i As Integer
        Dim SelectedProfile As String = "", SelectedProfilePath As String = ""
        If common.ShowBlankSelectionErrorMessage(ProfileName, "Profile") Then
            Exit Sub
        End If
        Dim fs As New FileStream(Common.SLPATH_CONST & Common.SLPROFILES_PATH, FileMode.Open, FileAccess.Read)
        xmldoc.Load(fs)
        Dim SelProfileName As String = ProfileName.SelectedItem.ToString
        xmlnode = xmldoc.GetElementsByTagName("csvprofile_name")
        For i = 0 To xmlnode.Count - 1
            SelectedProfile = xmlnode(i).ChildNodes.Item(0).InnerText.Trim()
            If SelectedProfile = SelProfileName Then
                xmlnode = xmldoc.GetElementsByTagName("csvprofile_path")
                SelectedProfilePath = xmlnode(i).ChildNodes.Item(0).InnerText.Trim()
            End If
        Next

        'FilePath = Application.StartupPath & "\bin\userconfig.ini"
        Dim TemplatePath As String = Common.SLPATH_CONST & "\pythonTemplates\desc.py"
        FilePath = Common.SLPATH_CONST & "\desc.py"
        My.Computer.FileSystem.CopyFile(TemplatePath, FilePath,
                        Microsoft.VisualBasic.FileIO.UIOption.OnlyErrorDialogs,
                        Microsoft.VisualBasic.FileIO.UICancelOption.DoNothing)
        Dim ExtractPath As String = Common.SLPATH_CONST & "extracts\"
        ExtractPath = ExtractPath & "extract_report_" & Path.GetFileName(SelectedProfilePath)
        IO.File.WriteAllText(FilePath, IO.File.ReadAllText(FilePath).Replace("#PROFILE_DATA#", SelectedProfilePath))
        IO.File.WriteAllText(FilePath, IO.File.ReadAllText(FilePath).Replace("#EXTRACT_PATH#", ExtractPath))

        Shell("python " & Common.SLPATH_CONST & "\desc.py")

        DGV.Rows.Clear()
        Dim fName As String = ExtractPath
        Dim TextLine As String = ""
        Dim SplitLine() As String
        Dim Count As Integer = 0
        If System.IO.File.Exists(fName) = True Then
            Using objReader As New System.IO.StreamReader(fName)
                Do While objReader.Peek() <> -1
                    TextLine = objReader.ReadLine()
                    TextLine = objReader.ReadLine()
                    SplitLine = Split(TextLine, ",")
                    DGV.Rows.Add(SplitLine)
                    Count += 1
                Loop
            End Using
        Else
            MsgBox("ERROR: File Does Not Exist")
        End If
        RecCount.Text = DGV.Rows.Count & " records."
        xmldoc.DocumentElement.ParentNode.RemoveAll()
    End Sub

    Private Sub Back_Click(sender As Object, e As EventArgs) Handles Back.Click
        Me.Close()
        YSMainMenu.Show()
    End Sub
End Class