﻿Imports System.Xml
Imports System.IO
Public Class XMLManager
    Public Shared Function ReadXMLTag(Path, xpath, TagName)
        Dim doc As New XmlDocument()
        doc.Load(Path)
        Dim tagval As String = ""
        Dim nodes As XmlNodeList = doc.DocumentElement.SelectNodes(xpath)
        For Each node As XmlNode In nodes
            tagval = node.SelectSingleNode(TagName).InnerText
        Next
        ReadXMLTag = tagval
    End Function
    Public Shared Sub WriteXMLTag(ByVal Path, ByVal xpath, ByVal TagName, ByVal enteredValue)
        Dim doc As New XmlDocument()
        doc.Load(Path)
        Dim tagval As String = ""
        Dim nodes As XmlNodeList = doc.DocumentElement.SelectNodes(xpath)
        For Each node As XmlNode In nodes
            node.SelectSingleNode(TagName).InnerText = enteredValue
        Next
        doc.Save(Path)
    End Sub
    Public Sub InsertNewNode(ByVal Path As String,
                                    ByVal profileName As String,
                                    ByVal CSVPath As String,
                                    ByVal CSVFileName As String
                                    )
        Dim doc As New XmlDocument()
        doc.Load(Path)
        Dim csvRoot As XmlNode = doc.CreateElement(XmlNodeType.Element, "csvprofile", Nothing)

        Dim csvprofileName As XmlNode = doc.CreateElement("csvprofile_name")
        csvprofileName.InnerText = profileName
        Dim csvprofilePath As XmlNode = doc.CreateElement("csvprofile_path")
        csvprofilePath.InnerText = CSVPath
        Dim csvXfileName As XmlNode = doc.CreateElement("csvfile_name")
        csvXfileName.InnerText = CSVFileName


        doc.DocumentElement.AppendChild(csvRoot)
        csvRoot.AppendChild(csvprofileName)
        csvRoot.AppendChild(csvprofilePath)
        csvRoot.AppendChild(csvXfileName)

        doc.Save(Path)
    End Sub
    Public Sub InsertNewRuleNode(ByVal Path As String,
                                    ByVal ruleName As String,
                                    ByVal rules As String
                                    )
        Dim doc As New XmlDocument()
        doc.Load(Path)
        Dim ruleRoot As XmlNode = doc.CreateElement(XmlNodeType.Element, "ruleProfile", Nothing)

        Dim ruleIDName As XmlNode = doc.CreateElement("rule_name")
        ruleIDName.InnerText = ruleName
        Dim ruleList As XmlNode = doc.CreateElement("rules")
        ruleList.InnerText = rules

        doc.DocumentElement.AppendChild(ruleRoot)
        ruleRoot.AppendChild(ruleIDName)
        ruleRoot.AppendChild(ruleList)
        doc.Save(Path)
    End Sub
    Public Shared Function getNodesCount(Path)
        Dim iNodeCount As Integer
        Dim doc As New XmlDocument()
        doc.Load(Path)
        Dim tagval As String = ""
        iNodeCount = doc.DocumentElement.SelectNodes("imageNode").Count
        getNodesCount = iNodeCount
    End Function
    Public Sub InsertNewModelNode(ByVal Path As String,
                                    ByVal modelName As String,
                                    ByVal trdata As String,
                                    ByVal tstdata As String,
                                    ByVal testsize As String,
                                    ByVal algo As String
                                    )
        Dim doc As New XmlDocument()
        doc.Load(Path)
        Dim modelRoot As XmlNode = doc.CreateElement(XmlNodeType.Element, "models", Nothing)

        Dim modelIDName As XmlNode = doc.CreateElement("model_name")
        modelIDName.InnerText = modelName
        Dim trainingData As XmlNode = doc.CreateElement("tr_profile")
        trainingData.InnerText = trdata
        Dim testData As XmlNode = doc.CreateElement("tst_profile")
        testData.InnerText = tstdata
        Dim tstsize As XmlNode = doc.CreateElement("tst_datasize")
        tstsize.InnerText = testsize
        Dim algorithm As XmlNode = doc.CreateElement("algo")
        algorithm.InnerText = algo

        doc.DocumentElement.AppendChild(modelRoot)
        modelRoot.AppendChild(modelIDName)
        modelRoot.AppendChild(trainingData)
        modelRoot.AppendChild(testData)
        modelRoot.AppendChild(tstsize)
        modelRoot.AppendChild(algorithm)
        doc.Save(Path)
    End Sub
    Public Shared Function GetDirectoryFromPath(ByVal Path As String)
        Dim ArrPath = Path.Split("\")
        Dim finalPath As String = ""
        For IVal = 0 To UBound(ArrPath) - 1
            finalPath = finalPath & ArrPath(IVal) & "\"
        Next
        finalPath = finalPath.Substring(0, finalPath.Length() - 1)
        GetDirectoryFromPath = finalPath
    End Function

    Public Sub RemoveProfileXMLNode(profileName As String)

        'Dim xmlnode As XmlNodeList
        'Dim xmldoc As New XmlDocument()
        'Dim fs As New FileStream(Common.SLPATH_CONST & Common.SLPROFILES_PATH, FileMode.Open, FileAccess.Read)
        'xmldoc.Load(fs)
        'Dim SelectedProfile As String = "", SelectedProfilePath As String = ""
        'Dim SelProfileName As String = profileName
        'xmlnode = xmldoc.GetElementsByTagName("csvprofile_name")
        'For i = 0 To XmlNode.Count - 1
        '    SelectedProfile = xmlnode(i).ChildNodes.Item(0).InnerText.Trim()
        '    If SelectedProfile = SelProfileName Then
        '        xmlnode = xmldoc.GetElementsByTagName("csvprofile")
        '        xmldoc.RemoveChild(xmlnode(i))
        '    End If
        'Next
        Dim doc As New XmlDocument()
        Dim nodes As XmlNodeList
        doc.Load(Common.SLPATH_CONST & Common.SLPROFILES_PATH)
        nodes = doc.GetElementsByTagName("csvprofile_name")
        Dim node As XmlNode

        For i = 0 To nodes.Count - 1
            node = doc.SelectSingleNode("/csvprofiles/csvprofile/csvprofile_name")
            If node.InnerText = profileName Then
                node.ParentNode.RemoveChild(node)
                doc.Save(Common.SLPATH_CONST & Common.SLPROFILES_PATH)
            End If
        Next


    End Sub
End Class

