﻿Imports System.IO
Imports System.Xml

Public Class Common

    Dim xmlnode As XmlNodeList
    Public Const SLPATH_CONST = "C:\slys\"
    Public Const SLPROFILES_PATH = "\\profiles.xml"
    Public Const SLMODELS_PATH = "\\models.xml"
    Public Const SLRULES_PATH = "\\rules.xml"
    Public Sub verifyNumericField(dropdown As Control, ByVal sFieldValue As String, minmaxDropdown As Control)
        If dropdown.Text = sFieldValue Then
            If minmaxDropdown.Text = "Min" Or minmaxDropdown.Text = "Max" Then
                MsgBox("ERROR: Only numeric fields are allowed", vbCritical, "YesSupply: Error")
            End If
        End If
    End Sub

    Public Sub ShowInGrid(DGV As System.Windows.Forms.DataGridView,
                          lblCount As System.Windows.Forms.Label,
                          fName As String)
        Dim TextLine As String = ""
        Dim SplitLine() As String
        Dim Count As Integer = 0
        If System.IO.File.Exists(fName) = True Then
            Using objReader As New System.IO.StreamReader(fName)
                Do While objReader.Peek() <> -1
                    TextLine = objReader.ReadLine()
                    TextLine = objReader.ReadLine()
                    SplitLine = Split(TextLine, ",")
                    DGV.Rows.Add(SplitLine)
                    Count += 1
                Loop
            End Using
        Else
            MsgBox("ERROR: File Does Not Exist")
        End If
        lblCount.Text = DGV.Rows.Count & " records."
    End Sub
    Public Sub ShowConfirmation(ByVal entity As String)
        MsgBox("The " & entity & " is saved successfully.", vbInformation, "YesSupply: Information")
    End Sub
    Public Sub ShowDelConfirmation(ByVal entity As String)
        MsgBox("The " & entity & " is deleted successfully.", vbInformation, "YesSupply: Information")
    End Sub
    Public Function ParseRuleString(ByVal unParsed As String)
        Dim finalString As String = "new_dataset = dataset["

        Dim mainArr() = unParsed.Split(";")
        For iRule As Integer = 0 To UBound(mainArr) - 1
            Dim singularRule() = mainArr(iRule).Split(":")

            Dim ruleType As String = singularRule(1)
            Dim columnName As String = singularRule(0)
            columnName = columnName.Replace(" ", String.Empty)
            If ruleType = "Min" Then
                finalString = finalString & "(dataset." & columnName & "==" _
                    & " dataset." & columnName & ".min()) | "

            ElseIf ruleType = "Max" Then
                finalString = finalString & "(dataset." & columnName & "==" _
                    & " dataset." & columnName & ".max()) | "
            End If
        Next
        finalString = finalString.Substring(0, finalString.Length() - 2)
        finalString = finalString & "]"
        ParseRuleString = finalString
    End Function
    Public Sub FillCommonCombos(ProfileName As System.Windows.Forms.ComboBox, fileName As String, tageName As String)
        Dim i As Integer
        Dim xmldoc As New XmlDataDocument()
        Dim fs As New FileStream(Common.SLPATH_CONST & fileName, FileMode.Open, FileAccess.Read)
        xmldoc.Load(fs)
        ProfileName.Items.Add("-- Select Your Option --")
        xmlnode = xmldoc.GetElementsByTagName(tageName) '"csvprofile_name"
        For i = 0 To xmlnode.Count - 1
            ProfileName.Items.Add(xmlnode(i).ChildNodes.Item(0).InnerText.Trim())
        Next
        ProfileName.SelectedIndex = 0
        xmldoc = Nothing
        fs.Close()
    End Sub
End Class
