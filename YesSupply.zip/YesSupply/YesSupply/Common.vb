﻿Imports System.IO
Imports System.Xml

Public Class Common

    Dim xmlnode As XmlNodeList
    Public Const SLPATH_CONST = "C:\slys\"
    Public Const SLPROFILES_PATH = "\\profiles.xml"
    Public Const SLMODELS_PATH = "\\models.xml"
    Public Const SLRULES_PATH = "\\rules.xml"
    Public Sub verifyNumericField(dropdown As Control, ByVal sFieldValue As String, minmaxDropdown As Control)
        If dropdown.Text = sFieldValue Then
            If minmaxDropdown.Text = "Min" Or minmaxDropdown.Text = "Max" Then
                MsgBox("ERROR: Only numeric fields are allowed", vbCritical, "YesSupply: Error")
            End If
        End If
    End Sub

    Public Sub ShowConfirmation(ByVal entity As String)
        MsgBox("The " & entity & " is saved successfully.", vbInformation, "YesSupply: Information")
    End Sub
    Public Sub ShowDelConfirmation(ByVal entity As String)
        MsgBox("The " & entity & " is deleted successfully.", vbInformation, "YesSupply: Information")
    End Sub
    Public Function ParseRuleString(ByVal unParsed As String)
        Dim finalString As String = "new_dataset = dataset["

        Dim mainArr() = unParsed.Split(";")
        For iRule As Integer = 0 To UBound(mainArr) - 1
            Dim singularRule() = mainArr(iRule).Split(":")

            Dim ruleType As String = singularRule(1)
            Dim columnName As String = singularRule(0)
            columnName = columnName.Replace(" ", String.Empty)
            If ruleType = "Min" Then
                finalString = finalString & "(dataset." & columnName & "==" _
                    & " dataset." & columnName & ".min()) | "

            ElseIf ruleType = "Max" Then
                finalString = finalString & "(dataset." & columnName & "==" _
                    & " dataset." & columnName & ".max()) | "
            End If
        Next
        finalString = finalString.Substring(0, finalString.Length() - 2)
        finalString = finalString & "]"
        ParseRuleString = finalString
    End Function
    Public Sub FillCommonCombos(ProfileName As System.Windows.Forms.ComboBox, fileName As String, tageName As String)
        Dim i As Integer
        Dim xmldoc As New XmlDataDocument()
        Dim fs As New FileStream(Common.SLPATH_CONST & fileName, FileMode.Open, FileAccess.Read)
        xmldoc.Load(fs)
        ProfileName.Items.Add("-- Select Your Option --")
        xmlnode = xmldoc.GetElementsByTagName(tageName) '"csvprofile_name"
        For i = 0 To xmlnode.Count - 1
            ProfileName.Items.Add(xmlnode(i).ChildNodes.Item(0).InnerText.Trim())
        Next
        ProfileName.SelectedIndex = 0
        xmldoc = Nothing
        fs.Close()
    End Sub

    Public Function ShowBlankFieldErrorMessage(editbox As System.Windows.Forms.TextBox, sElement As String)
        Dim Flag As Boolean
        If editbox.Text = "" Then
            MsgBox(sElement & " should not be blank", vbCritical, "Yes-Supply: Error")
            Flag = True
        Else
            Flag = False
        End If
        ShowBlankFieldErrorMessage = Flag
    End Function
    Public Function ShowBlankSelectionErrorMessage(combo As System.Windows.Forms.ComboBox, sElement As String)
        Dim Flag As Boolean
        If combo.SelectedIndex = 0 Then
            MsgBox(sElement & " should be selected.", vbCritical, "Yes-Supply: Error")
            Flag = True
        Else
            Flag = False
        End If
        ShowBlankSelectionErrorMessage = Flag
    End Function
End Class
