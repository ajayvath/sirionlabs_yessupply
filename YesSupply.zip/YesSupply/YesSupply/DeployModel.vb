﻿Imports System.IO
Imports System.Xml
Public Class DeployModel
    Dim XMLObject As New XMLManager
    Dim common As New Common
    Dim xmldoc As New XmlDataDocument()
    Dim xmlnode As XmlNodeList
    Private Sub Back_Click(sender As Object, e As EventArgs) Handles Back.Click
        Me.Close()
        YSMainMenu.Show()
    End Sub

    Private Sub SaveModel_Click(sender As Object, e As EventArgs) Handles SaveModel.Click
        Dim directory As String = Common.SLPATH_CONST
        Dim filePath As String = directory & "\\models.xml"
        If Not System.IO.Directory.Exists(directory) Then
            System.IO.Directory.CreateDirectory(directory)
        End If
        If Not System.IO.File.Exists(filePath) Then
            System.IO.File.Create(filePath).Dispose()
        End If
        Dim vbAns = MsgBox("Are you sure you want to add new record for the model?", vbQuestion & vbYesNo, "YesSupply: Confirmation")
        If vbAns = vbYes Then
            XMLObject.InsertNewModelNode(filePath,
        ModelName.Text, TrainingDataPName.Text, TestDataPName.Text, TestDataSize.Text, Algorithm.Text)
            common.ShowConfirmation("model")
        Else
            'Do Nothing
        End If
    End Sub

    Private Sub DeployModel_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        common.FillCommonCombos(TestDataPName, Common.SLPROFILES_PATH, "csvprofile_name")
        common.FillCommonCombos(TrainingDataPName, Common.SLPROFILES_PATH, "csvprofile_name")
        Algorithm.SelectedIndex = 0
    End Sub

    Private Sub Algorithm_SelectedIndexChanged(sender As Object, e As EventArgs) Handles Algorithm.SelectedIndexChanged
        If Algorithm.Text = "LogIT (Stats Model)" Then
            TestDataSize.Text = "0.0"
            TestDataSize.Enabled = False
        Else
            TestDataSize.Text = ""
            TestDataSize.Enabled = True
        End If
    End Sub
End Class