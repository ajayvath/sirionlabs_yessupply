﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ManageRuleEngine
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ManageRuleEngine))
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PBLogo = New System.Windows.Forms.PictureBox()
        Me.RuleName = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.EQTB4 = New System.Windows.Forms.TextBox()
        Me.EQTB3 = New System.Windows.Forms.TextBox()
        Me.EQTB2 = New System.Windows.Forms.TextBox()
        Me.EQTB1 = New System.Windows.Forms.TextBox()
        Me.MinMax4 = New System.Windows.Forms.ComboBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.FN4 = New System.Windows.Forms.ComboBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.MinMax3 = New System.Windows.Forms.ComboBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.FN3 = New System.Windows.Forms.ComboBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.MinMax2 = New System.Windows.Forms.ComboBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.FN2 = New System.Windows.Forms.ComboBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.MinMax1 = New System.Windows.Forms.ComboBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.FN1 = New System.Windows.Forms.ComboBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Back = New System.Windows.Forms.Button()
        Me.SaveRule = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        CType(Me.PBLogo, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(119, 12)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.GroupBox1.Size = New System.Drawing.Size(960, 80)
        Me.GroupBox1.TabIndex = 7
        Me.GroupBox1.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Bookman Old Style", 22.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label1.ForeColor = System.Drawing.Color.ForestGreen
        Me.Label1.Location = New System.Drawing.Point(10, 21)
        Me.Label1.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(407, 44)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Manage Rule Engine"
        '
        'PBLogo
        '
        Me.PBLogo.Image = CType(resources.GetObject("PBLogo.Image"), System.Drawing.Image)
        Me.PBLogo.Location = New System.Drawing.Point(14, 12)
        Me.PBLogo.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.PBLogo.Name = "PBLogo"
        Me.PBLogo.Size = New System.Drawing.Size(100, 100)
        Me.PBLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PBLogo.TabIndex = 6
        Me.PBLogo.TabStop = False
        '
        'RuleName
        '
        Me.RuleName.Location = New System.Drawing.Point(162, 133)
        Me.RuleName.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.RuleName.Name = "RuleName"
        Me.RuleName.Size = New System.Drawing.Size(903, 31)
        Me.RuleName.TabIndex = 14
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label2.ForeColor = System.Drawing.Color.ForestGreen
        Me.Label2.Location = New System.Drawing.Point(36, 131)
        Me.Label2.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(129, 23)
        Me.Label2.TabIndex = 13
        Me.Label2.Text = "Rule Name :"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.EQTB4)
        Me.GroupBox2.Controls.Add(Me.EQTB3)
        Me.GroupBox2.Controls.Add(Me.EQTB2)
        Me.GroupBox2.Controls.Add(Me.EQTB1)
        Me.GroupBox2.Controls.Add(Me.MinMax4)
        Me.GroupBox2.Controls.Add(Me.Label9)
        Me.GroupBox2.Controls.Add(Me.FN4)
        Me.GroupBox2.Controls.Add(Me.Label10)
        Me.GroupBox2.Controls.Add(Me.MinMax3)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.FN3)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Controls.Add(Me.MinMax2)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Controls.Add(Me.FN2)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.MinMax1)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Controls.Add(Me.FN1)
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Location = New System.Drawing.Point(23, 182)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.GroupBox2.Size = New System.Drawing.Size(1056, 228)
        Me.GroupBox2.TabIndex = 15
        Me.GroupBox2.TabStop = False
        '
        'EQTB4
        '
        Me.EQTB4.Location = New System.Drawing.Point(815, 165)
        Me.EQTB4.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.EQTB4.Name = "EQTB4"
        Me.EQTB4.Size = New System.Drawing.Size(233, 31)
        Me.EQTB4.TabIndex = 36
        '
        'EQTB3
        '
        Me.EQTB3.Location = New System.Drawing.Point(815, 119)
        Me.EQTB3.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.EQTB3.Name = "EQTB3"
        Me.EQTB3.Size = New System.Drawing.Size(233, 31)
        Me.EQTB3.TabIndex = 34
        '
        'EQTB2
        '
        Me.EQTB2.Location = New System.Drawing.Point(815, 78)
        Me.EQTB2.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.EQTB2.Name = "EQTB2"
        Me.EQTB2.Size = New System.Drawing.Size(233, 31)
        Me.EQTB2.TabIndex = 33
        '
        'EQTB1
        '
        Me.EQTB1.Location = New System.Drawing.Point(815, 34)
        Me.EQTB1.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.EQTB1.Name = "EQTB1"
        Me.EQTB1.Size = New System.Drawing.Size(233, 31)
        Me.EQTB1.TabIndex = 32
        '
        'MinMax4
        '
        Me.MinMax4.AutoCompleteCustomSource.AddRange(New String() {"Min", "Max", "Equals"})
        Me.MinMax4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.MinMax4.FormattingEnabled = True
        Me.MinMax4.Items.AddRange(New Object() {"Min", "Max", "Equals"})
        Me.MinMax4.Location = New System.Drawing.Point(617, 170)
        Me.MinMax4.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.MinMax4.Name = "MinMax4"
        Me.MinMax4.Size = New System.Drawing.Size(183, 31)
        Me.MinMax4.TabIndex = 31
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label9.ForeColor = System.Drawing.Color.ForestGreen
        Me.Label9.Location = New System.Drawing.Point(550, 173)
        Me.Label9.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(67, 23)
        Me.Label9.TabIndex = 30
        Me.Label9.Text = "Rule :"
        '
        'FN4
        '
        Me.FN4.AutoCompleteCustomSource.AddRange(New String() {"Supplier Name", "Region", "Country", "Function", "Services", "Avg. Cost($)", "Rating", "Average Delivery Time", "Number of Escalations", "Year", "Resources"})
        Me.FN4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.FN4.FormattingEnabled = True
        Me.FN4.Items.AddRange(New Object() {"Supplier Name", "Region", "Country", "Function", "Services", "Avg. Cost($)", "Rating", "Average Delivery Time", "Number of Escalations", "Year", "Resources"})
        Me.FN4.Location = New System.Drawing.Point(160, 170)
        Me.FN4.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.FN4.Name = "FN4"
        Me.FN4.Size = New System.Drawing.Size(374, 31)
        Me.FN4.TabIndex = 29
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label10.ForeColor = System.Drawing.Color.ForestGreen
        Me.Label10.Location = New System.Drawing.Point(0, 173)
        Me.Label10.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(150, 23)
        Me.Label10.TabIndex = 28
        Me.Label10.Text = "Field Name 4 :"
        '
        'MinMax3
        '
        Me.MinMax3.AutoCompleteCustomSource.AddRange(New String() {"Min", "Max", "Equals"})
        Me.MinMax3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.MinMax3.FormattingEnabled = True
        Me.MinMax3.Items.AddRange(New Object() {"Min", "Max", "Equals"})
        Me.MinMax3.Location = New System.Drawing.Point(617, 124)
        Me.MinMax3.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.MinMax3.Name = "MinMax3"
        Me.MinMax3.Size = New System.Drawing.Size(183, 31)
        Me.MinMax3.TabIndex = 27
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label7.ForeColor = System.Drawing.Color.ForestGreen
        Me.Label7.Location = New System.Drawing.Point(550, 127)
        Me.Label7.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(67, 23)
        Me.Label7.TabIndex = 26
        Me.Label7.Text = "Rule :"
        '
        'FN3
        '
        Me.FN3.AutoCompleteCustomSource.AddRange(New String() {"Supplier Name", "Region", "Country", "Function", "Services", "Avg. Cost($)", "Rating", "Average Delivery Time", "Number of Escalations", "Year", "Resources"})
        Me.FN3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.FN3.FormattingEnabled = True
        Me.FN3.Items.AddRange(New Object() {"Supplier Name", "Region", "Country", "Function", "Services", "Avg. Cost($)", "Rating", "Average Delivery Time", "Number of Escalations", "Year", "Resources"})
        Me.FN3.Location = New System.Drawing.Point(157, 124)
        Me.FN3.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.FN3.Name = "FN3"
        Me.FN3.Size = New System.Drawing.Size(374, 31)
        Me.FN3.TabIndex = 25
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label8.ForeColor = System.Drawing.Color.ForestGreen
        Me.Label8.Location = New System.Drawing.Point(0, 127)
        Me.Label8.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(150, 23)
        Me.Label8.TabIndex = 24
        Me.Label8.Text = "Field Name 3 :"
        '
        'MinMax2
        '
        Me.MinMax2.AutoCompleteCustomSource.AddRange(New String() {"Min", "Max", "Equals"})
        Me.MinMax2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.MinMax2.FormattingEnabled = True
        Me.MinMax2.Items.AddRange(New Object() {"Min", "Max", "Equals"})
        Me.MinMax2.Location = New System.Drawing.Point(617, 78)
        Me.MinMax2.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.MinMax2.Name = "MinMax2"
        Me.MinMax2.Size = New System.Drawing.Size(183, 31)
        Me.MinMax2.TabIndex = 23
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label5.ForeColor = System.Drawing.Color.ForestGreen
        Me.Label5.Location = New System.Drawing.Point(550, 81)
        Me.Label5.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(67, 23)
        Me.Label5.TabIndex = 22
        Me.Label5.Text = "Rule :"
        '
        'FN2
        '
        Me.FN2.AutoCompleteCustomSource.AddRange(New String() {"Supplier Name", "Region", "Country", "Function", "Services", "Avg. Cost($)", "Rating", "Average Delivery Time", "Number of Escalations", "Year", "Resources"})
        Me.FN2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.FN2.FormattingEnabled = True
        Me.FN2.Items.AddRange(New Object() {"Supplier Name", "Region", "Country", "Function", "Services", "Avg. Cost($)", "Rating", "Average Delivery Time", "Number of Escalations", "Year", "Resources"})
        Me.FN2.Location = New System.Drawing.Point(157, 78)
        Me.FN2.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.FN2.Name = "FN2"
        Me.FN2.Size = New System.Drawing.Size(374, 31)
        Me.FN2.TabIndex = 21
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label6.ForeColor = System.Drawing.Color.ForestGreen
        Me.Label6.Location = New System.Drawing.Point(0, 81)
        Me.Label6.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(150, 23)
        Me.Label6.TabIndex = 20
        Me.Label6.Text = "Field Name 2 :"
        '
        'MinMax1
        '
        Me.MinMax1.AutoCompleteCustomSource.AddRange(New String() {"Min", "Max", "Equals"})
        Me.MinMax1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.MinMax1.FormattingEnabled = True
        Me.MinMax1.Items.AddRange(New Object() {"Min", "Max", "Equals"})
        Me.MinMax1.Location = New System.Drawing.Point(617, 34)
        Me.MinMax1.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.MinMax1.Name = "MinMax1"
        Me.MinMax1.Size = New System.Drawing.Size(183, 31)
        Me.MinMax1.TabIndex = 19
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label4.ForeColor = System.Drawing.Color.ForestGreen
        Me.Label4.Location = New System.Drawing.Point(550, 41)
        Me.Label4.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(67, 23)
        Me.Label4.TabIndex = 18
        Me.Label4.Text = "Rule :"
        '
        'FN1
        '
        Me.FN1.AutoCompleteCustomSource.AddRange(New String() {"Supplier Name", "Region", "Country", "Function", "Services", "Avg. Cost($)", "Rating", "Average Delivery Time", "Number of Escalations", "Year", "Resources"})
        Me.FN1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.FN1.FormattingEnabled = True
        Me.FN1.Items.AddRange(New Object() {"Supplier Name", "Region", "Country", "Function", "Services", "Avg. Cost($)", "Rating", "Average Delivery Time", "Number of Escalations", "Year", "Resources"})
        Me.FN1.Location = New System.Drawing.Point(157, 34)
        Me.FN1.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.FN1.Name = "FN1"
        Me.FN1.Size = New System.Drawing.Size(374, 31)
        Me.FN1.TabIndex = 17
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label3.ForeColor = System.Drawing.Color.ForestGreen
        Me.Label3.Location = New System.Drawing.Point(0, 41)
        Me.Label3.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(150, 23)
        Me.Label3.TabIndex = 16
        Me.Label3.Text = "Field Name 1 :"
        '
        'Back
        '
        Me.Back.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Back.Location = New System.Drawing.Point(20, 419)
        Me.Back.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.Back.Name = "Back"
        Me.Back.Size = New System.Drawing.Size(89, 42)
        Me.Back.TabIndex = 31
        Me.Back.Text = "< &Back"
        Me.Back.UseVisualStyleBackColor = True
        '
        'SaveRule
        '
        Me.SaveRule.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.SaveRule.Location = New System.Drawing.Point(119, 419)
        Me.SaveRule.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.SaveRule.Name = "SaveRule"
        Me.SaveRule.Size = New System.Drawing.Size(127, 44)
        Me.SaveRule.TabIndex = 30
        Me.SaveRule.Text = "Save &Rule"
        Me.SaveRule.UseVisualStyleBackColor = True
        '
        'ManageRuleEngine
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(13.0!, 23.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1083, 470)
        Me.Controls.Add(Me.Back)
        Me.Controls.Add(Me.SaveRule)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.RuleName)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.PBLogo)
        Me.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.MaximizeBox = False
        Me.Name = "ManageRuleEngine"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "YesSuplly : Manage Rule Engine"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.PBLogo, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Label1 As Label
    Friend WithEvents PBLogo As PictureBox
    Friend WithEvents RuleName As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents FN1 As ComboBox
    Friend WithEvents MinMax1 As ComboBox
    Friend WithEvents MinMax4 As ComboBox
    Friend WithEvents Label9 As Label
    Friend WithEvents FN4 As ComboBox
    Friend WithEvents Label10 As Label
    Friend WithEvents MinMax3 As ComboBox
    Friend WithEvents Label7 As Label
    Friend WithEvents FN3 As ComboBox
    Friend WithEvents Label8 As Label
    Friend WithEvents MinMax2 As ComboBox
    Friend WithEvents Label5 As Label
    Friend WithEvents FN2 As ComboBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Back As Button
    Friend WithEvents SaveRule As Button
    Friend WithEvents EQTB4 As TextBox
    Friend WithEvents EQTB3 As TextBox
    Friend WithEvents EQTB2 As TextBox
    Friend WithEvents EQTB1 As TextBox
End Class
