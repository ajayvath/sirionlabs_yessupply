﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class ApplyModel
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ApplyModel))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PBLogo = New System.Windows.Forms.PictureBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.ModelName = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.SelectedCriteria = New System.Windows.Forms.ComboBox()
        Me.DGV = New System.Windows.Forms.DataGridView()
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ExportExcel = New System.Windows.Forms.Button()
        Me.Back = New System.Windows.Forms.Button()
        Me.AppMdl = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        CType(Me.PBLogo, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DGV, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(114, 7)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(873, 92)
        Me.GroupBox1.TabIndex = 5
        Me.GroupBox1.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Bookman Old Style", 22.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label1.ForeColor = System.Drawing.Color.ForestGreen
        Me.Label1.Location = New System.Drawing.Point(15, 27)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(258, 44)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Apply Model"
        '
        'PBLogo
        '
        Me.PBLogo.Image = CType(resources.GetObject("PBLogo.Image"), System.Drawing.Image)
        Me.PBLogo.Location = New System.Drawing.Point(8, 7)
        Me.PBLogo.Name = "PBLogo"
        Me.PBLogo.Size = New System.Drawing.Size(100, 100)
        Me.PBLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PBLogo.TabIndex = 4
        Me.PBLogo.TabStop = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label5.ForeColor = System.Drawing.Color.ForestGreen
        Me.Label5.Location = New System.Drawing.Point(112, 113)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(282, 23)
        Me.Label5.TabIndex = 43
        Me.Label5.Text = "Data Science Model Name : "
        '
        'ModelName
        '
        Me.ModelName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ModelName.FormattingEnabled = True
        Me.ModelName.Location = New System.Drawing.Point(396, 110)
        Me.ModelName.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.ModelName.Name = "ModelName"
        Me.ModelName.Size = New System.Drawing.Size(430, 31)
        Me.ModelName.TabIndex = 42
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label2.ForeColor = System.Drawing.Color.ForestGreen
        Me.Label2.Location = New System.Drawing.Point(114, 160)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(280, 23)
        Me.Label2.TabIndex = 44
        Me.Label2.Text = "Selected Supplier Critetia : "
        '
        'SelectedCriteria
        '
        Me.SelectedCriteria.AutoCompleteCustomSource.AddRange(New String() {"-- Select Your Option --", "Top 10 Only", "Top 50 Only", "Top 100 Only"})
        Me.SelectedCriteria.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.SelectedCriteria.FormattingEnabled = True
        Me.SelectedCriteria.Items.AddRange(New Object() {"-- Select Your Option --", "Top 10 Only", "Top 50 Only", "Top 100 Only"})
        Me.SelectedCriteria.Location = New System.Drawing.Point(396, 157)
        Me.SelectedCriteria.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.SelectedCriteria.Name = "SelectedCriteria"
        Me.SelectedCriteria.Size = New System.Drawing.Size(430, 31)
        Me.SelectedCriteria.TabIndex = 45
        '
        'DGV
        '
        Me.DGV.AllowUserToAddRows = False
        Me.DGV.AllowUserToDeleteRows = False
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        DataGridViewCellStyle1.ForeColor = System.Drawing.Color.Maroon
        Me.DGV.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.DGV.ColumnHeadersHeight = 29
        Me.DGV.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1, Me.Column2})
        Me.DGV.Location = New System.Drawing.Point(11, 208)
        Me.DGV.Name = "DGV"
        Me.DGV.ReadOnly = True
        Me.DGV.RowHeadersWidth = 51
        Me.DGV.RowTemplate.Height = 29
        Me.DGV.Size = New System.Drawing.Size(970, 366)
        Me.DGV.TabIndex = 46
        '
        'Column1
        '
        Me.Column1.HeaderText = "Supplier Name"
        Me.Column1.MinimumWidth = 6
        Me.Column1.Name = "Column1"
        Me.Column1.ReadOnly = True
        Me.Column1.Width = 125
        '
        'Column2
        '
        Me.Column2.HeaderText = "Selected Flag"
        Me.Column2.MinimumWidth = 6
        Me.Column2.Name = "Column2"
        Me.Column2.ReadOnly = True
        Me.Column2.Width = 125
        '
        'ExportExcel
        '
        Me.ExportExcel.Font = New System.Drawing.Font("Segoe UI", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.ExportExcel.Location = New System.Drawing.Point(9, 580)
        Me.ExportExcel.Name = "ExportExcel"
        Me.ExportExcel.Size = New System.Drawing.Size(127, 38)
        Me.ExportExcel.TabIndex = 47
        Me.ExportExcel.Text = "Export &Excel"
        Me.ExportExcel.UseVisualStyleBackColor = True
        '
        'Back
        '
        Me.Back.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Back.Location = New System.Drawing.Point(8, 154)
        Me.Back.Name = "Back"
        Me.Back.Size = New System.Drawing.Size(96, 40)
        Me.Back.TabIndex = 49
        Me.Back.Text = "< &Back"
        Me.Back.UseVisualStyleBackColor = True
        '
        'AppMdl
        '
        Me.AppMdl.Location = New System.Drawing.Point(845, 151)
        Me.AppMdl.Name = "AppMdl"
        Me.AppMdl.Size = New System.Drawing.Size(139, 40)
        Me.AppMdl.TabIndex = 50
        Me.AppMdl.Text = "Apply &Model"
        Me.AppMdl.UseVisualStyleBackColor = True
        '
        'ApplyModel
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(13.0!, 23.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(999, 629)
        Me.Controls.Add(Me.AppMdl)
        Me.Controls.Add(Me.Back)
        Me.Controls.Add(Me.ExportExcel)
        Me.Controls.Add(Me.DGV)
        Me.Controls.Add(Me.SelectedCriteria)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.ModelName)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.PBLogo)
        Me.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.MaximizeBox = False
        Me.Name = "ApplyModel"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Yes-Supply : Apply Model"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.PBLogo, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DGV, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Label1 As Label
    Friend WithEvents PBLogo As PictureBox
    Friend WithEvents Label5 As Label
    Friend WithEvents ModelName As ComboBox
    Friend WithEvents Label2 As Label
    Friend WithEvents SelectedCriteria As ComboBox
    Friend WithEvents DGV As DataGridView
    Friend WithEvents ExportExcel As Button
    Friend WithEvents Back As Button
    Friend WithEvents AppMdl As Button
    Friend WithEvents Column1 As DataGridViewTextBoxColumn
    Friend WithEvents Column2 As DataGridViewTextBoxColumn
End Class
