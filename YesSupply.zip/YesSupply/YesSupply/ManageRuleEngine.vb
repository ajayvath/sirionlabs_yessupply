﻿Public Class ManageRuleEngine
    Dim XMLObject As New XMLManager()
    Dim common As New Common
    Private Sub Back_Click(sender As Object, e As EventArgs) Handles Back.Click
        Me.Close()
        YSMainMenu.Show()
    End Sub

    Private Sub MinMax1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles MinMax1.SelectedIndexChanged
        If MinMax1.Text = "Equals" Then
            EQTB1.Visible = True
        Else
            EQTB1.Visible = False
        End If
        common.verifyNumericField(FN1, "Region", MinMax1)
        common.verifyNumericField(FN1, "Supplier Name", MinMax1)
        common.verifyNumericField(FN1, "Country", MinMax1)
        common.verifyNumericField(FN1, "Function", MinMax1)
        common.verifyNumericField(FN1, "Services", MinMax1)
    End Sub

    Private Sub ManageRuleEngine_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        EQTB1.Visible = False
        EQTB2.Visible = False
        EQTB3.Visible = False
        EQTB4.Visible = False
        FN1.SelectedIndex = 0
        FN2.SelectedIndex = 0
        FN3.SelectedIndex = 0
        FN4.SelectedIndex = 0
        MinMax1.SelectedIndex = 0
        MinMax2.SelectedIndex = 0
        MinMax3.SelectedIndex = 0
        MinMax4.SelectedIndex = 0
    End Sub

    Private Sub MinMax2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles MinMax2.SelectedIndexChanged
        If MinMax2.Text = "Equals" Then
            EQTB2.Visible = True
        Else
            EQTB2.Visible = False
        End If
        common.verifyNumericField(FN2, "Region", MinMax2)
        common.verifyNumericField(FN2, "Supplier Name", MinMax2)
        common.verifyNumericField(FN2, "Country", MinMax2)
        common.verifyNumericField(FN2, "Function", MinMax2)
        common.verifyNumericField(FN2, "Services", MinMax2)
    End Sub

    Private Sub MinMax3_SelectedIndexChanged(sender As Object, e As EventArgs) Handles MinMax3.SelectedIndexChanged
        If MinMax3.Text = "Equals" Then
            EQTB3.Visible = True
        Else
            EQTB3.Visible = False
        End If
        common.verifyNumericField(FN3, "Region", MinMax3)
        common.verifyNumericField(FN3, "Supplier Name", MinMax3)
        common.verifyNumericField(FN3, "Country", MinMax3)
        common.verifyNumericField(FN3, "Function", MinMax3)
        common.verifyNumericField(FN3, "Services", MinMax3)
    End Sub

    Private Sub MinMax4_SelectedIndexChanged(sender As Object, e As EventArgs) Handles MinMax4.SelectedIndexChanged
        If MinMax4.Text = "Equals" Then
            EQTB4.Visible = True
        Else
            EQTB4.Visible = False
        End If
        common.verifyNumericField(FN4, "Region", MinMax4)
        common.verifyNumericField(FN4, "Supplier Name", MinMax4)
        common.verifyNumericField(FN4, "Country", MinMax4)
        common.verifyNumericField(FN4, "Function", MinMax4)
        common.verifyNumericField(FN4, "Services", MinMax4)
    End Sub

    Private Sub SaveRule_Click(sender As Object, e As EventArgs) Handles SaveRule.Click
        Dim directory As String = Common.SLPATH_CONST
        Dim filePath As String = Common.SLPATH_CONST & "\\rules.xml"
        If Not System.IO.Directory.Exists(directory) Then
            System.IO.Directory.CreateDirectory(directory)
        End If
        If Not System.IO.File.Exists(filePath) Then
            System.IO.File.Create(filePath).Dispose()
        End If
        Dim ruleText As String = ""
        If Not FN1.Text = "" Then
            If MinMax1.Text = "Equals" Then
                ruleText = ruleText & "" & FN1.Text & ":" & "=" & EQTB1.Text & ";"
            Else
                ruleText = ruleText & "" & FN1.Text & ":" & MinMax1.Text & ";"
            End If
        End If
        If Not FN2.Text = "" Then
            If MinMax2.Text = "Equals" Then
                ruleText = ruleText & "" & FN2.Text & ":" & "=" & EQTB2.Text & ";"
            Else
                ruleText = ruleText & "" & FN2.Text & ":" & MinMax2.Text & ";"
            End If
        End If
        If Not FN3.Text = "" Then
            If MinMax3.Text = "Equals" Then
                ruleText = ruleText & "" & FN3.Text & ":" & "=" & EQTB3.Text & ";"
            Else
                ruleText = ruleText & "" & FN3.Text & ":" & MinMax3.Text & ";"
            End If
        End If
        If Not FN4.Text = "" Then
            If MinMax3.Text = "Equals" Then
                ruleText = ruleText & "" & FN4.Text & ":" & "=" & EQTB4.Text & ";"
            Else
                ruleText = ruleText & "" & FN4.Text & ":" & MinMax4.Text & ";"
            End If
        End If
        Dim vbAns = MsgBox("Are you sure you want to add new record for the rule?", vbQuestion & vbYesNo, "YesSupply: Confirmation")
        If vbAns = vbYes Then
            XMLObject.InsertNewRuleNode(filePath,
        RuleName.Text, ruleText)
            common.ShowConfirmation("rule")
        Else
            'Do Nothing
        End If

    End Sub
End Class