﻿Imports System.IO
Imports System.Xml
Public Class ApplyRule
    Dim xmldoc As New XmlDataDocument()
    Dim xmldocRule As New XmlDataDocument()
    Dim common As New Common()
    Dim xmlnode As XmlNodeList
    Private Sub Back_Click(sender As Object, e As EventArgs) Handles Back.Click
        Me.Close()
        YSMainMenu.Show()
    End Sub
    Private Sub ApplyRule_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        common.FillCommonCombos(ProfileName, Common.SLPROFILES_PATH, "csvprofile_name")
        common.FillCommonCombos(Rules, Common.SLRULES_PATH, "rule_name")
        Dim fs As New FileStream(Common.SLPATH_CONST & Common.SLPROFILES_PATH, FileMode.Open, FileAccess.Read)
        xmldoc.Load(fs)

    End Sub
    Private Sub AppRules_Click(sender As Object, e As EventArgs) Handles AppRules.Click
        Dim SelectedProfile As String = "", SelectedProfilePath As String = ""
        Dim SelProfileName As String = ProfileName.SelectedItem.ToString

        xmlnode = xmldoc.GetElementsByTagName("csvprofile_name")
        For i = 0 To xmlnode.Count - 1
            SelectedProfile = xmlnode(i).ChildNodes.Item(0).InnerText.Trim()
            If SelectedProfile = SelProfileName Then
                xmlnode = xmldoc.GetElementsByTagName("csvprofile_path")
                SelectedProfilePath = xmlnode(i).ChildNodes.Item(0).InnerText.Trim()
            End If
        Next

        Dim SelectedRule As String = "", SelectedActRule As String = ""
        Dim SelRule As String = Rules.SelectedItem.ToString

        Dim fs2 As New FileStream(Common.SLPATH_CONST & Common.SLRULES_PATH, FileMode.Open, FileAccess.Read)
        xmldocRule.Load(fs2)

        xmlnode = xmldocRule.GetElementsByTagName("rule_name")
        For i = 0 To xmlnode.Count - 1
            SelectedRule = xmlnode(i).ChildNodes.Item(0).InnerText.Trim()
            If SelectedRule = SelRule Then
                xmlnode = xmldocRule.GetElementsByTagName("rules")
                SelectedActRule = xmlnode(i).ChildNodes.Item(0).InnerText.Trim()
                Exit For
            End If
        Next

        Dim myRule = common.ParseRuleString(SelectedActRule)

        Dim TemplatePath As String = Common.SLPATH_CONST & "pythonTemplates\rules.py"
        Dim FilePath As String
        FilePath = "C:\slys\rules.py"
        My.Computer.FileSystem.CopyFile(TemplatePath, FilePath,
                        Microsoft.VisualBasic.FileIO.UIOption.OnlyErrorDialogs,
                        Microsoft.VisualBasic.FileIO.UICancelOption.DoNothing)
        Dim ExtractPath As String = Common.SLPATH_CONST & "\extracts\"
        ExtractPath = ExtractPath & "extract_rules_" & Path.GetFileName(SelectedProfilePath)
        IO.File.WriteAllText(FilePath, IO.File.ReadAllText(FilePath).Replace("#PROFILE_DATA#", SelectedProfilePath))

        My.Computer.FileSystem.WriteAllText(FilePath, myRule, True)
        Dim extractionLine As String = vbCrLf & "new_dataset.to_csv(r'" & ExtractPath & "' , index=False)"
        My.Computer.FileSystem.WriteAllText(FilePath, extractionLine, True)

        Shell("python " & Common.SLPATH_CONST & "\rules.py")

        DGV.Rows.Clear()
        Dim fName As String = ExtractPath
        Dim TextLine As String = ""
        Dim SplitLine() As String
        Dim Count As Integer = 0
        If System.IO.File.Exists(fName) = True Then
            Using objReader As New System.IO.StreamReader(fName)
                Do While objReader.Peek() <> -1
                    TextLine = objReader.ReadLine()
                    TextLine = objReader.ReadLine()
                    SplitLine = Split(TextLine, ",")
                    DGV.Rows.Add(SplitLine)
                    Count += 1
                Loop
            End Using
        Else
            MsgBox("ERROR: File Does Not Exist")
        End If
        RecCount.Text = DGV.Rows.Count & " records."

    End Sub
End Class