﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class YSMainMenu
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(YSMainMenu))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.YSMenu = New System.Windows.Forms.MenuStrip()
        Me.CSVProfileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ManageCSVProfileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ViewProfileDataToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DataToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AddSupplierToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ManageSupplierToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RuleEngineToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ManageRulesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ApplyRuleEngineToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DataScienceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DeployAlgorithmToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ApplyAlgorithmToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReportingToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ProfileDescribeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PBLogo = New System.Windows.Forms.PictureBox()
        Me.Back = New System.Windows.Forms.Button()
        Me.TBC = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.DGV_Profiles = New System.Windows.Forms.DataGridView()
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.DGV_Rules = New System.Windows.Forms.DataGridView()
        Me.Column4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.DGV_Model = New System.Windows.Forms.DataGridView()
        Me.Column6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column8 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column9 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column10 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.MergeProfilesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.YSMenu.SuspendLayout()
        CType(Me.PBLogo, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TBC.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        CType(Me.DGV_Profiles, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout()
        CType(Me.DGV_Rules, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage3.SuspendLayout()
        CType(Me.DGV_Model, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'YSMenu
        '
        Me.YSMenu.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.YSMenu.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CSVProfileToolStripMenuItem, Me.DataToolStripMenuItem, Me.RuleEngineToolStripMenuItem, Me.DataScienceToolStripMenuItem, Me.ReportingToolStripMenuItem})
        Me.YSMenu.Location = New System.Drawing.Point(0, 0)
        Me.YSMenu.Name = "YSMenu"
        Me.YSMenu.Size = New System.Drawing.Size(1002, 28)
        Me.YSMenu.TabIndex = 0
        Me.YSMenu.Text = "YSMenu"
        '
        'CSVProfileToolStripMenuItem
        '
        Me.CSVProfileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ManageCSVProfileToolStripMenuItem, Me.ViewProfileDataToolStripMenuItem})
        Me.CSVProfileToolStripMenuItem.Name = "CSVProfileToolStripMenuItem"
        Me.CSVProfileToolStripMenuItem.Size = New System.Drawing.Size(96, 24)
        Me.CSVProfileToolStripMenuItem.Text = "CSV &Profile"
        '
        'ManageCSVProfileToolStripMenuItem
        '
        Me.ManageCSVProfileToolStripMenuItem.Name = "ManageCSVProfileToolStripMenuItem"
        Me.ManageCSVProfileToolStripMenuItem.Size = New System.Drawing.Size(236, 26)
        Me.ManageCSVProfileToolStripMenuItem.Text = "Manage CSV Profile ..."
        '
        'ViewProfileDataToolStripMenuItem
        '
        Me.ViewProfileDataToolStripMenuItem.Name = "ViewProfileDataToolStripMenuItem"
        Me.ViewProfileDataToolStripMenuItem.Size = New System.Drawing.Size(236, 26)
        Me.ViewProfileDataToolStripMenuItem.Text = "View &Profile (Data) ...."
        '
        'DataToolStripMenuItem
        '
        Me.DataToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AddSupplierToolStripMenuItem, Me.ManageSupplierToolStripMenuItem, Me.MergeProfilesToolStripMenuItem})
        Me.DataToolStripMenuItem.Name = "DataToolStripMenuItem"
        Me.DataToolStripMenuItem.Size = New System.Drawing.Size(55, 24)
        Me.DataToolStripMenuItem.Text = "&Data"
        '
        'AddSupplierToolStripMenuItem
        '
        Me.AddSupplierToolStripMenuItem.Name = "AddSupplierToolStripMenuItem"
        Me.AddSupplierToolStripMenuItem.Size = New System.Drawing.Size(224, 26)
        Me.AddSupplierToolStripMenuItem.Text = "&Add Supplier ..."
        '
        'ManageSupplierToolStripMenuItem
        '
        Me.ManageSupplierToolStripMenuItem.Name = "ManageSupplierToolStripMenuItem"
        Me.ManageSupplierToolStripMenuItem.Size = New System.Drawing.Size(224, 26)
        Me.ManageSupplierToolStripMenuItem.Text = "&Manage Supplier ..."
        '
        'RuleEngineToolStripMenuItem
        '
        Me.RuleEngineToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ManageRulesToolStripMenuItem, Me.ApplyRuleEngineToolStripMenuItem})
        Me.RuleEngineToolStripMenuItem.Name = "RuleEngineToolStripMenuItem"
        Me.RuleEngineToolStripMenuItem.Size = New System.Drawing.Size(101, 24)
        Me.RuleEngineToolStripMenuItem.Text = "Rule Engine"
        '
        'ManageRulesToolStripMenuItem
        '
        Me.ManageRulesToolStripMenuItem.Name = "ManageRulesToolStripMenuItem"
        Me.ManageRulesToolStripMenuItem.Size = New System.Drawing.Size(198, 26)
        Me.ManageRulesToolStripMenuItem.Text = "&Manage Rules ..."
        '
        'ApplyRuleEngineToolStripMenuItem
        '
        Me.ApplyRuleEngineToolStripMenuItem.Name = "ApplyRuleEngineToolStripMenuItem"
        Me.ApplyRuleEngineToolStripMenuItem.Size = New System.Drawing.Size(198, 26)
        Me.ApplyRuleEngineToolStripMenuItem.Text = "Apply &Rule  ..."
        '
        'DataScienceToolStripMenuItem
        '
        Me.DataScienceToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DeployAlgorithmToolStripMenuItem, Me.ApplyAlgorithmToolStripMenuItem})
        Me.DataScienceToolStripMenuItem.Name = "DataScienceToolStripMenuItem"
        Me.DataScienceToolStripMenuItem.Size = New System.Drawing.Size(109, 24)
        Me.DataScienceToolStripMenuItem.Text = "Data Science"
        '
        'DeployAlgorithmToolStripMenuItem
        '
        Me.DeployAlgorithmToolStripMenuItem.Name = "DeployAlgorithmToolStripMenuItem"
        Me.DeployAlgorithmToolStripMenuItem.Size = New System.Drawing.Size(196, 26)
        Me.DeployAlgorithmToolStripMenuItem.Text = "Deploy Model..."
        '
        'ApplyAlgorithmToolStripMenuItem
        '
        Me.ApplyAlgorithmToolStripMenuItem.Name = "ApplyAlgorithmToolStripMenuItem"
        Me.ApplyAlgorithmToolStripMenuItem.Size = New System.Drawing.Size(196, 26)
        Me.ApplyAlgorithmToolStripMenuItem.Text = "Apply Model ..."
        '
        'ReportingToolStripMenuItem
        '
        Me.ReportingToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ProfileDescribeToolStripMenuItem})
        Me.ReportingToolStripMenuItem.Name = "ReportingToolStripMenuItem"
        Me.ReportingToolStripMenuItem.Size = New System.Drawing.Size(89, 24)
        Me.ReportingToolStripMenuItem.Text = "Reporting"
        '
        'ProfileDescribeToolStripMenuItem
        '
        Me.ProfileDescribeToolStripMenuItem.Name = "ProfileDescribeToolStripMenuItem"
        Me.ProfileDescribeToolStripMenuItem.Size = New System.Drawing.Size(210, 26)
        Me.ProfileDescribeToolStripMenuItem.Text = "Profile Describe ..."
        '
        'PBLogo
        '
        Me.PBLogo.Image = CType(resources.GetObject("PBLogo.Image"), System.Drawing.Image)
        Me.PBLogo.Location = New System.Drawing.Point(886, 333)
        Me.PBLogo.Name = "PBLogo"
        Me.PBLogo.Size = New System.Drawing.Size(100, 100)
        Me.PBLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PBLogo.TabIndex = 3
        Me.PBLogo.TabStop = False
        '
        'Back
        '
        Me.Back.Font = New System.Drawing.Font("Bookman Old Style", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Back.Image = CType(resources.GetObject("Back.Image"), System.Drawing.Image)
        Me.Back.Location = New System.Drawing.Point(12, 333)
        Me.Back.Name = "Back"
        Me.Back.Size = New System.Drawing.Size(83, 83)
        Me.Back.TabIndex = 30
        Me.Back.UseVisualStyleBackColor = True
        '
        'TBC
        '
        Me.TBC.Controls.Add(Me.TabPage1)
        Me.TBC.Controls.Add(Me.TabPage2)
        Me.TBC.Controls.Add(Me.TabPage3)
        Me.TBC.Location = New System.Drawing.Point(12, 41)
        Me.TBC.Name = "TBC"
        Me.TBC.SelectedIndex = 0
        Me.TBC.Size = New System.Drawing.Size(978, 277)
        Me.TBC.TabIndex = 31
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.DGV_Profiles)
        Me.TabPage1.Location = New System.Drawing.Point(4, 29)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(970, 244)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Profiles"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'DGV_Profiles
        '
        Me.DGV_Profiles.AllowUserToAddRows = False
        Me.DGV_Profiles.AllowUserToDeleteRows = False
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Bookman Old Style", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        DataGridViewCellStyle1.ForeColor = System.Drawing.Color.Maroon
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DGV_Profiles.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.DGV_Profiles.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DGV_Profiles.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.DGV_Profiles.ColumnHeadersHeight = 29
        Me.DGV_Profiles.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1, Me.Column2, Me.Column3})
        Me.DGV_Profiles.Location = New System.Drawing.Point(22, 20)
        Me.DGV_Profiles.Name = "DGV_Profiles"
        Me.DGV_Profiles.ReadOnly = True
        Me.DGV_Profiles.RowHeadersWidth = 51
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Bookman Old Style", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.DGV_Profiles.RowsDefaultCellStyle = DataGridViewCellStyle2
        Me.DGV_Profiles.RowTemplate.Height = 29
        Me.DGV_Profiles.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DGV_Profiles.Size = New System.Drawing.Size(924, 205)
        Me.DGV_Profiles.TabIndex = 0
        '
        'Column1
        '
        Me.Column1.HeaderText = "Profile Name"
        Me.Column1.MinimumWidth = 6
        Me.Column1.Name = "Column1"
        Me.Column1.ReadOnly = True
        '
        'Column2
        '
        Me.Column2.HeaderText = "Profile Path"
        Me.Column2.MinimumWidth = 6
        Me.Column2.Name = "Column2"
        Me.Column2.ReadOnly = True
        '
        'Column3
        '
        Me.Column3.HeaderText = "CSV File Name"
        Me.Column3.MinimumWidth = 6
        Me.Column3.Name = "Column3"
        Me.Column3.ReadOnly = True
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.DGV_Rules)
        Me.TabPage2.Location = New System.Drawing.Point(4, 29)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(970, 244)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Rules"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'DGV_Rules
        '
        Me.DGV_Rules.AllowUserToAddRows = False
        Me.DGV_Rules.AllowUserToDeleteRows = False
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Bookman Old Style", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        DataGridViewCellStyle3.ForeColor = System.Drawing.Color.Maroon
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DGV_Rules.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle3
        Me.DGV_Rules.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DGV_Rules.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.DGV_Rules.ColumnHeadersHeight = 29
        Me.DGV_Rules.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column4, Me.Column5})
        Me.DGV_Rules.Location = New System.Drawing.Point(23, 20)
        Me.DGV_Rules.Name = "DGV_Rules"
        Me.DGV_Rules.ReadOnly = True
        Me.DGV_Rules.RowHeadersWidth = 51
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Bookman Old Style", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.DGV_Rules.RowsDefaultCellStyle = DataGridViewCellStyle4
        Me.DGV_Rules.RowTemplate.Height = 29
        Me.DGV_Rules.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DGV_Rules.Size = New System.Drawing.Size(924, 205)
        Me.DGV_Rules.TabIndex = 1
        '
        'Column4
        '
        Me.Column4.HeaderText = "Rule Name"
        Me.Column4.MinimumWidth = 6
        Me.Column4.Name = "Column4"
        Me.Column4.ReadOnly = True
        '
        'Column5
        '
        Me.Column5.HeaderText = "Rule String"
        Me.Column5.MinimumWidth = 6
        Me.Column5.Name = "Column5"
        Me.Column5.ReadOnly = True
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.DGV_Model)
        Me.TabPage3.Location = New System.Drawing.Point(4, 29)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Size = New System.Drawing.Size(970, 244)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Models"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'DGV_Model
        '
        Me.DGV_Model.AllowUserToAddRows = False
        Me.DGV_Model.AllowUserToDeleteRows = False
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft
        DataGridViewCellStyle5.Font = New System.Drawing.Font("Bookman Old Style", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        DataGridViewCellStyle5.ForeColor = System.Drawing.Color.Maroon
        DataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DGV_Model.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle5
        Me.DGV_Model.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DGV_Model.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.DGV_Model.ColumnHeadersHeight = 29
        Me.DGV_Model.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column6, Me.Column7, Me.Column8, Me.Column9, Me.Column10})
        Me.DGV_Model.Location = New System.Drawing.Point(23, 20)
        Me.DGV_Model.Name = "DGV_Model"
        Me.DGV_Model.ReadOnly = True
        Me.DGV_Model.RowHeadersWidth = 51
        DataGridViewCellStyle6.Font = New System.Drawing.Font("Bookman Old Style", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.DGV_Model.RowsDefaultCellStyle = DataGridViewCellStyle6
        Me.DGV_Model.RowTemplate.Height = 29
        Me.DGV_Model.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DGV_Model.Size = New System.Drawing.Size(924, 205)
        Me.DGV_Model.TabIndex = 2
        '
        'Column6
        '
        Me.Column6.HeaderText = "Model Name"
        Me.Column6.MinimumWidth = 6
        Me.Column6.Name = "Column6"
        Me.Column6.ReadOnly = True
        '
        'Column7
        '
        Me.Column7.HeaderText = "Training Profile"
        Me.Column7.MinimumWidth = 6
        Me.Column7.Name = "Column7"
        Me.Column7.ReadOnly = True
        '
        'Column8
        '
        Me.Column8.HeaderText = "Test Profile"
        Me.Column8.MinimumWidth = 6
        Me.Column8.Name = "Column8"
        Me.Column8.ReadOnly = True
        '
        'Column9
        '
        Me.Column9.HeaderText = "Datasize"
        Me.Column9.MinimumWidth = 6
        Me.Column9.Name = "Column9"
        Me.Column9.ReadOnly = True
        '
        'Column10
        '
        Me.Column10.HeaderText = "Algorithm"
        Me.Column10.MinimumWidth = 6
        Me.Column10.Name = "Column10"
        Me.Column10.ReadOnly = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Bookman Old Style", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label1.Location = New System.Drawing.Point(706, 333)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(174, 21)
        Me.Label1.TabIndex = 32
        Me.Label1.Text = "Version : 1.0.0 Beta"
        '
        'MergeProfilesToolStripMenuItem
        '
        Me.MergeProfilesToolStripMenuItem.Name = "MergeProfilesToolStripMenuItem"
        Me.MergeProfilesToolStripMenuItem.Size = New System.Drawing.Size(224, 26)
        Me.MergeProfilesToolStripMenuItem.Text = "Merge Profiles ..."
        '
        'YSMainMenu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1002, 445)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PBLogo)
        Me.Controls.Add(Me.TBC)
        Me.Controls.Add(Me.Back)
        Me.Controls.Add(Me.YSMenu)
        Me.MainMenuStrip = Me.YSMenu
        Me.Name = "YSMainMenu"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Welcome to Yes-Supply - Your Supplier Guide"
        Me.YSMenu.ResumeLayout(False)
        Me.YSMenu.PerformLayout()
        CType(Me.PBLogo, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TBC.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        CType(Me.DGV_Profiles, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        CType(Me.DGV_Rules, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage3.ResumeLayout(False)
        CType(Me.DGV_Model, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout

End Sub

    Friend WithEvents YSMenu As MenuStrip
    Friend WithEvents DataToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AddSupplierToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ManageSupplierToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents RuleEngineToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ManageRulesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ApplyRuleEngineToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DataScienceToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DeployAlgorithmToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ApplyAlgorithmToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PBLogo As PictureBox
    Friend WithEvents CSVProfileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ManageCSVProfileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ViewProfileDataToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Back As Button
    Friend WithEvents ReportingToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ProfileDescribeToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TBC As TabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents DGV_Profiles As DataGridView
    Friend WithEvents Column1 As DataGridViewTextBoxColumn
    Friend WithEvents Column2 As DataGridViewTextBoxColumn
    Friend WithEvents Column3 As DataGridViewTextBoxColumn
    Friend WithEvents TabPage3 As TabPage
    Friend WithEvents Label1 As Label
    Friend WithEvents DGV_Rules As DataGridView
    Friend WithEvents Column4 As DataGridViewTextBoxColumn
    Friend WithEvents Column5 As DataGridViewTextBoxColumn
    Friend WithEvents DGV_Model As DataGridView
    Friend WithEvents Column6 As DataGridViewTextBoxColumn
    Friend WithEvents Column7 As DataGridViewTextBoxColumn
    Friend WithEvents Column8 As DataGridViewTextBoxColumn
    Friend WithEvents Column9 As DataGridViewTextBoxColumn
    Friend WithEvents Column10 As DataGridViewTextBoxColumn
    Friend WithEvents MergeProfilesToolStripMenuItem As ToolStripMenuItem
End Class
