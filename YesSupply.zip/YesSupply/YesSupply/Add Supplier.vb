﻿Imports System.IO
Imports System.Xml
Public Class Add_Supplier
    Dim xmldoc As New XmlDataDocument()
    Dim xmlnode As XmlNodeList
    Dim SelectedProfilePath As String
    Dim common As New Common
    Private Sub Back_Click(sender As Object, e As EventArgs) Handles Back.Click
        Me.Close()
        YSMainMenu.Show()
    End Sub
    Private Sub Add_Supplier_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        common.FillCommonCombos(ProfileName, "\\profiles.xml", "csvprofile_name")
        Regions.SelectedIndex = 0
        Services.SelectedIndex = 0
        SFunction.SelectedIndex = 0
    End Sub

    Private Sub UpdateCSV_Click(sender As Object, e As EventArgs) Handles UpdateCSV.Click
        If common.ShowBlankFieldErrorMessage(SupplierName, "Supplier Name") Then
            Exit Sub
        End If
        If common.ShowBlankSelectionErrorMessage(Regions, "Region") Then
            Exit Sub
        End If
        If common.ShowBlankFieldErrorMessage(Country, "Country") Then
            Exit Sub
        End If
        If common.ShowBlankSelectionErrorMessage(SFunction, "Function") Then
            Exit Sub
        End If
        If common.ShowBlankSelectionErrorMessage(Services, "Services") Then
            Exit Sub
        End If
        If common.ShowBlankFieldErrorMessage(AvgCost, "Avg. Cost") Then
            Exit Sub
        End If

        If common.ShowBlankFieldErrorMessage(Rating, "Rating") Then
            Exit Sub
        End If
        If common.ShowBlankSelectionErrorMessage(ProfileName, "Profile") Then
            Exit Sub
        End If
        If common.ShowBlankFieldErrorMessage(AvgDeliveryTime, "Avg. Delivery Time") Then
            Exit Sub
        End If
        If common.ShowBlankFieldErrorMessage(Escalations, "Escalations") Then
            Exit Sub
        End If
        If common.ShowBlankFieldErrorMessage(Years, "Year") Then
            Exit Sub
        End If
        If common.ShowBlankFieldErrorMessage(Resourcess, "Resources") Then
            Exit Sub
        End If

        Dim CSV As String = SupplierName.Text & "," & Regions.Text & "," & Country.Text _
            & "," & SFunction.Text & "," & AvgCost.Text & "," & Rating.Text & "," &
            AvgDeliveryTime.Text & "," & Escalations.Text & "," & Years.Text & "," &
            Resourcess.Text
        Dim fs As New FileStream(Common.SLPATH_CONST & Common.SLPROFILES_PATH, FileMode.Open, FileAccess.Read)
        xmldoc.Load(fs)
        Dim SelectedProfile As String = "", SelectedProfilePath As String = ""
        Dim SelProfileName As String = ProfileName.SelectedItem.ToString
        xmlnode = xmldoc.GetElementsByTagName("csvprofile_name")
        For i = 0 To xmlnode.Count - 1
            SelectedProfile = xmlnode(i).ChildNodes.Item(0).InnerText.Trim()
            If SelectedProfile = SelProfileName Then
                xmlnode = xmldoc.GetElementsByTagName("csvprofile_path")
                SelectedProfilePath = xmlnode(i).ChildNodes.Item(0).InnerText.Trim()
            End If
        Next
        Dim vbAns = MsgBox("Do you wish to add this supplier to the selected supplier profile ?", vbQuestion + vbYesNo, "Yes-Supply: Confimation")
        If vbAns = vbYes Then
            My.Computer.FileSystem.WriteAllText(
          SelectedProfilePath, CSV, True)
            common.ShowConfirmation("supplier")
        Else
            'Do Nothing
        End If

    End Sub
End Class