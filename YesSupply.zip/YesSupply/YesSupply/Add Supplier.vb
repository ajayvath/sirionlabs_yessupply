﻿Imports System.IO
Imports System.Xml
Public Class Add_Supplier
    Dim xmldoc As New XmlDataDocument()
    Dim xmlnode As XmlNodeList
    Dim SelectedProfilePath As String
    Dim common As New Common
    Private Sub Back_Click(sender As Object, e As EventArgs) Handles Back.Click
        Me.Close()
        YSMainMenu.Show()
    End Sub

    Private Sub Add_Supplier_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        common.FillCommonCombos(ProfileName, "\\profiles.xml", "csvprofile_name")
    End Sub

    Private Sub UpdateCSV_Click(sender As Object, e As EventArgs) Handles UpdateCSV.Click
        Dim CSV As String = SupplierName.Text & "," & Regions.Text & "," & Country.Text _
            & "," & SFunction.Text & "," & AvgCost.Text & "," & Rating.Text & "," &
            AvgDeliveryTime.Text & "," & Escalations.Text & "," & Years.Text & "," &
            Resourcess.Text

        Dim SelectedProfile As String = "", SelectedProfilePath As String = ""
        Dim SelProfileName As String = ProfileName.SelectedItem.ToString
        xmlnode = xmldoc.GetElementsByTagName("csvprofile_name")
        For i = 0 To xmlnode.Count - 1
            SelectedProfile = xmlnode(i).ChildNodes.Item(0).InnerText.Trim()
            If SelectedProfile = SelProfileName Then
                xmlnode = xmldoc.GetElementsByTagName("csvprofile_path")
                SelectedProfilePath = xmlnode(i).ChildNodes.Item(0).InnerText.Trim()
            End If
        Next

        My.Computer.FileSystem.WriteAllText(
          SelectedProfilePath, CSV, True)
        common.ShowConfirmation("supplier")
    End Sub
End Class