﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Add_Supplier
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Add_Supplier))
        Me.PBLogo = New System.Windows.Forms.PictureBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.SupplierName = New System.Windows.Forms.TextBox()
        Me.Country = New System.Windows.Forms.TextBox()
        Me.AvgCost = New System.Windows.Forms.TextBox()
        Me.Rating = New System.Windows.Forms.TextBox()
        Me.SFunction = New System.Windows.Forms.ComboBox()
        Me.Services = New System.Windows.Forms.ComboBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.AvgDeliveryTime = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Escalations = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Years = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.UpdateCSV = New System.Windows.Forms.Button()
        Me.Back = New System.Windows.Forms.Button()
        Me.Regions = New System.Windows.Forms.ComboBox()
        Me.PB2 = New System.Windows.Forms.PictureBox()
        Me.ProfileName = New System.Windows.Forms.ComboBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Resourcess = New System.Windows.Forms.TextBox()
        CType(Me.PBLogo, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        CType(Me.PB2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PBLogo
        '
        Me.PBLogo.Image = CType(resources.GetObject("PBLogo.Image"), System.Drawing.Image)
        Me.PBLogo.Location = New System.Drawing.Point(13, 12)
        Me.PBLogo.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.PBLogo.Name = "PBLogo"
        Me.PBLogo.Size = New System.Drawing.Size(100, 100)
        Me.PBLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PBLogo.TabIndex = 2
        Me.PBLogo.TabStop = False
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(123, 12)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.GroupBox1.Size = New System.Drawing.Size(925, 92)
        Me.GroupBox1.TabIndex = 3
        Me.GroupBox1.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Bookman Old Style", 22.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label1.ForeColor = System.Drawing.Color.ForestGreen
        Me.Label1.Location = New System.Drawing.Point(10, 27)
        Me.Label1.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(267, 44)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Add Supplier"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label2.ForeColor = System.Drawing.Color.ForestGreen
        Me.Label2.Location = New System.Drawing.Point(15, 123)
        Me.Label2.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(167, 23)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Supplier Name :"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label3.ForeColor = System.Drawing.Color.ForestGreen
        Me.Label3.Location = New System.Drawing.Point(94, 170)
        Me.Label3.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(88, 23)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Region :"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label4.ForeColor = System.Drawing.Color.ForestGreen
        Me.Label4.Location = New System.Drawing.Point(79, 214)
        Me.Label4.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(103, 23)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Country :"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label5.ForeColor = System.Drawing.Color.ForestGreen
        Me.Label5.Location = New System.Drawing.Point(72, 257)
        Me.Label5.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(110, 23)
        Me.Label5.TabIndex = 7
        Me.Label5.Text = "Function :"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label6.ForeColor = System.Drawing.Color.ForestGreen
        Me.Label6.Location = New System.Drawing.Point(89, 303)
        Me.Label6.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(93, 23)
        Me.Label6.TabIndex = 8
        Me.Label6.Text = "Service :"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label7.ForeColor = System.Drawing.Color.ForestGreen
        Me.Label7.Location = New System.Drawing.Point(38, 351)
        Me.Label7.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(144, 23)
        Me.Label7.TabIndex = 9
        Me.Label7.Text = "Avg. Cost ($) :"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label8.ForeColor = System.Drawing.Color.ForestGreen
        Me.Label8.Location = New System.Drawing.Point(90, 394)
        Me.Label8.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(92, 23)
        Me.Label8.TabIndex = 10
        Me.Label8.Text = "Rating : "
        '
        'SupplierName
        '
        Me.SupplierName.Location = New System.Drawing.Point(192, 121)
        Me.SupplierName.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.SupplierName.Name = "SupplierName"
        Me.SupplierName.Size = New System.Drawing.Size(357, 31)
        Me.SupplierName.TabIndex = 1
        '
        'Country
        '
        Me.Country.Location = New System.Drawing.Point(192, 210)
        Me.Country.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.Country.Name = "Country"
        Me.Country.Size = New System.Drawing.Size(357, 31)
        Me.Country.TabIndex = 3
        '
        'AvgCost
        '
        Me.AvgCost.Location = New System.Drawing.Point(192, 348)
        Me.AvgCost.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.AvgCost.Name = "AvgCost"
        Me.AvgCost.Size = New System.Drawing.Size(357, 31)
        Me.AvgCost.TabIndex = 6
        '
        'Rating
        '
        Me.Rating.Location = New System.Drawing.Point(192, 391)
        Me.Rating.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.Rating.Name = "Rating"
        Me.Rating.Size = New System.Drawing.Size(357, 31)
        Me.Rating.TabIndex = 7
        '
        'SFunction
        '
        Me.SFunction.AutoCompleteCustomSource.AddRange(New String() {"HR", "IT & Infrastructure", "Administration", "Consulting", "Marketing", "Procurement"})
        Me.SFunction.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.SFunction.FormattingEnabled = True
        Me.SFunction.Items.AddRange(New Object() {"-- Select Your Option --", "HR", "IT & Infrastructure", "Administration", "Consulting", "Marketing", "Procurement"})
        Me.SFunction.Location = New System.Drawing.Point(192, 257)
        Me.SFunction.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.SFunction.Name = "SFunction"
        Me.SFunction.Size = New System.Drawing.Size(357, 31)
        Me.SFunction.TabIndex = 4
        '
        'Services
        '
        Me.Services.AutoCompleteCustomSource.AddRange(New String() {"Applications Development", "Applications Development & Maintenance", "Mainframe services", "Service Desk", "Consultation"})
        Me.Services.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Services.FormattingEnabled = True
        Me.Services.Items.AddRange(New Object() {"-- Select Your Option --", "Applications Development", "Applications Development & Maintenance", "Mainframe services", "Service Desk", "Consultation"})
        Me.Services.Location = New System.Drawing.Point(192, 300)
        Me.Services.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.Services.Name = "Services"
        Me.Services.Size = New System.Drawing.Size(357, 31)
        Me.Services.TabIndex = 5
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label9.ForeColor = System.Drawing.Color.ForestGreen
        Me.Label9.Location = New System.Drawing.Point(559, 122)
        Me.Label9.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(188, 28)
        Me.Label9.TabIndex = 18
        Me.Label9.Text = "Avg. Delivery Time : "
        '
        'AvgDeliveryTime
        '
        Me.AvgDeliveryTime.Location = New System.Drawing.Point(747, 119)
        Me.AvgDeliveryTime.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.AvgDeliveryTime.Name = "AvgDeliveryTime"
        Me.AvgDeliveryTime.Size = New System.Drawing.Size(301, 31)
        Me.AvgDeliveryTime.TabIndex = 8
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label10.ForeColor = System.Drawing.Color.ForestGreen
        Me.Label10.Location = New System.Drawing.Point(626, 168)
        Me.Label10.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(121, 28)
        Me.Label10.TabIndex = 20
        Me.Label10.Text = "Escalations : "
        '
        'Escalations
        '
        Me.Escalations.Location = New System.Drawing.Point(747, 165)
        Me.Escalations.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.Escalations.Name = "Escalations"
        Me.Escalations.Size = New System.Drawing.Size(301, 31)
        Me.Escalations.TabIndex = 9
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label12.ForeColor = System.Drawing.Color.ForestGreen
        Me.Label12.Location = New System.Drawing.Point(673, 213)
        Me.Label12.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(62, 28)
        Me.Label12.TabIndex = 22
        Me.Label12.Text = "Year : "
        '
        'Years
        '
        Me.Years.Location = New System.Drawing.Point(745, 210)
        Me.Years.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.Years.Name = "Years"
        Me.Years.Size = New System.Drawing.Size(301, 31)
        Me.Years.TabIndex = 10
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label13.ForeColor = System.Drawing.Color.ForestGreen
        Me.Label13.Location = New System.Drawing.Point(635, 262)
        Me.Label13.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(112, 28)
        Me.Label13.TabIndex = 24
        Me.Label13.Text = "Resources : "
        '
        'UpdateCSV
        '
        Me.UpdateCSV.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.UpdateCSV.Location = New System.Drawing.Point(123, 480)
        Me.UpdateCSV.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.UpdateCSV.Name = "UpdateCSV"
        Me.UpdateCSV.Size = New System.Drawing.Size(146, 40)
        Me.UpdateCSV.TabIndex = 27
        Me.UpdateCSV.Text = "Add S&upplier"
        Me.UpdateCSV.UseVisualStyleBackColor = True
        '
        'Back
        '
        Me.Back.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Back.Location = New System.Drawing.Point(13, 480)
        Me.Back.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.Back.Name = "Back"
        Me.Back.Size = New System.Drawing.Size(96, 40)
        Me.Back.TabIndex = 29
        Me.Back.Text = "< &Back"
        Me.Back.UseVisualStyleBackColor = True
        '
        'Regions
        '
        Me.Regions.AutoCompleteCustomSource.AddRange(New String() {"North America", "South America", "Asia", "APAC", "Africa", "Europe"})
        Me.Regions.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Regions.FormattingEnabled = True
        Me.Regions.Items.AddRange(New Object() {"-- Select Your Option --", "North America", "South America", "Asia", "APAC", "Africa", "Europe"})
        Me.Regions.Location = New System.Drawing.Point(192, 166)
        Me.Regions.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.Regions.Name = "Regions"
        Me.Regions.Size = New System.Drawing.Size(357, 31)
        Me.Regions.TabIndex = 2
        '
        'PB2
        '
        Me.PB2.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.PB2.Image = CType(resources.GetObject("PB2.Image"), System.Drawing.Image)
        Me.PB2.ImageLocation = ""
        Me.PB2.InitialImage = CType(resources.GetObject("PB2.InitialImage"), System.Drawing.Image)
        Me.PB2.Location = New System.Drawing.Point(816, 343)
        Me.PB2.Name = "PB2"
        Me.PB2.Size = New System.Drawing.Size(215, 153)
        Me.PB2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PB2.TabIndex = 31
        Me.PB2.TabStop = False
        '
        'ProfileName
        '
        Me.ProfileName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ProfileName.FormattingEnabled = True
        Me.ProfileName.Location = New System.Drawing.Point(192, 433)
        Me.ProfileName.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.ProfileName.Name = "ProfileName"
        Me.ProfileName.Size = New System.Drawing.Size(357, 31)
        Me.ProfileName.TabIndex = 32
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label11.ForeColor = System.Drawing.Color.ForestGreen
        Me.Label11.Location = New System.Drawing.Point(38, 433)
        Me.Label11.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(145, 23)
        Me.Label11.TabIndex = 33
        Me.Label11.Text = "Profile Name :"
        '
        'Resourcess
        '
        Me.Resourcess.Location = New System.Drawing.Point(747, 259)
        Me.Resourcess.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.Resourcess.Name = "Resourcess"
        Me.Resourcess.Size = New System.Drawing.Size(301, 31)
        Me.Resourcess.TabIndex = 11
        '
        'Add_Supplier
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(13.0!, 23.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(1057, 535)
        Me.Controls.Add(Me.Resourcess)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.ProfileName)
        Me.Controls.Add(Me.PB2)
        Me.Controls.Add(Me.Regions)
        Me.Controls.Add(Me.Back)
        Me.Controls.Add(Me.UpdateCSV)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Years)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Escalations)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.AvgDeliveryTime)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Services)
        Me.Controls.Add(Me.SFunction)
        Me.Controls.Add(Me.Rating)
        Me.Controls.Add(Me.AvgCost)
        Me.Controls.Add(Me.Country)
        Me.Controls.Add(Me.SupplierName)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.PBLogo)
        Me.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.MaximizeBox = False
        Me.Name = "Add_Supplier"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Yes-Supply : Add New Supplier"
        CType(Me.PBLogo, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.PB2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents PBLogo As PictureBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents SupplierName As TextBox
    Friend WithEvents Country As TextBox
    Friend WithEvents AvgCost As TextBox
    Friend WithEvents Rating As TextBox
    Friend WithEvents SFunction As ComboBox
    Friend WithEvents Services As ComboBox
    Friend WithEvents Label9 As Label
    Friend WithEvents AvgDeliveryTime As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents Escalations As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents Years As TextBox
    Friend WithEvents Resources As TextBox
    Friend WithEvents Label13 As Label
    Friend WithEvents UpdateCSV As Button
    Friend WithEvents Back As Button
    Friend WithEvents Regions As ComboBox
    Friend WithEvents PB2 As PictureBox
    Friend WithEvents ProfileName As ComboBox
    Friend WithEvents Label11 As Label
    Friend WithEvents Resourcess As TextBox
End Class
