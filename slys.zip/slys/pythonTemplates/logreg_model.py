import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split 
from sklearn.metrics import confusion_matrix 

dataset = pd.read_csv(r'#PROFILE_DATA#')


dataset.rename(columns = {'Average Delivery Time':'AverageDeliveryTime'}, inplace = True)
dataset.rename(columns = {'Number of Escalations':'NumberofEscalations'}, inplace = True)

x = dataset.iloc[:,1:-1].values
y = dataset.iloc[:,-1:].values