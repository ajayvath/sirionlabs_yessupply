import pandas as pd

dataset = pd.read_csv(r'#PROFILE_DATA#')
dataset.describe().to_csv(r'#EXTRACT_PATH#')