import pandas as pd

dataset = pd.read_csv(r'#PROFILE_DATA#')


dataset.rename(columns = {'Average Delivery Time':'AverageDeliveryTime'}, inplace = True)
dataset.rename(columns = {'Number of Escalations':'NumberofEscalations'}, inplace = True)
