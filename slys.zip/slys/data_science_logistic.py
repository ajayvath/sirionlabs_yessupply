#!/usr/bin/env python
# coding: utf-8

import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split 

#Loading Training Set
dataset = pd.read_csv(r'C:\slys\data\SirionLabsSample1.csv')

#Renaming columnbs which are having spaces
dataset.rename(columns = {'Average Delivery Time':'AverageDeliveryTime'}, inplace = True)
dataset.rename(columns = {'Number of Escalations':'NumberofEscalations'}, inplace = True)


dataset['Selected_Flag'] = dataset['Selected_Flag'].map({'Y':1, 'N':0})


#Categorical Columns - Using one hot encoding to include the columns in data analysis.

#ONE-HOT ENCODING - REGION
dataset_regions = pd.get_dummies(dataset['Region'])
dataset = dataset.join(dataset_regions)
dataset.drop('Region',axis=1, inplace=True)

#ONE-HOT ENCODING - FUNCTION
dataset_functions = pd.get_dummies(dataset['Function'])
dataset = dataset.join(dataset_functions)
dataset.drop('Function',axis=1, inplace=True)

#ONE-HOT ENCODING - SERVICES
dataset_service = pd.get_dummies(dataset['Services'])
dataset = dataset.join(dataset_service)
dataset.drop('Services',axis=1, inplace=True)

#ONE-HOT ENCODING - COUNTRY
dataset_country = pd.get_dummies(dataset['Country'])
dataset = dataset.join(dataset_country)
dataset.drop('Country',axis=1, inplace=True)

#:::NO OUTPUT in Yes-Supply::: Verifying null (NaNs) in OHE data
dataset_functions.isnull().values.any()
dataset_regions.isnull().values.any()
dataset_service.isnull().values.any()
dataset_country.isnull().values.any()

# Put the selection at the back
dataset = dataset.reindex(columns = [col for col in dataset.columns if col != 'Selected_Flag'] + ['Selected_Flag'])

#Selecting all features except Supplier Name as it is a Key column
x = dataset.iloc[:,1:-1].values
y = dataset.iloc[:,-1:].values

#divide dataset into train and test sets.
x_train, x_test, y_train, y_test= train_test_split(x, y, test_size= 0.25, random_state=0)  

#Feature scaling using Standard Scalar
scaleXY = StandardScaler()
x_train= scaleXY.fit_transform(x_train)    
x_test= scaleXY.transform(x_test)  

#Deploying Logistic Regression Model
logReg = LogisticRegression(random_state=0)  
logReg.fit(x_train, y_train)   

#:::NO OUTPUT in Yes-Supply::: R-Squared for both training and test data.
#NOTE: The R-Squared of this data is currently being displayed as 56-60% which is way too low
#      One of the reason is - The data is not real but simulated (mostly incorrect to identify patterns (possibly the explanation power 
#      on the variables are very small because of randomness and simulation of data. Real time data will have better results.
r_squared = logReg.score(x_train, y_train)
r_squared_test = logReg.score(x_test, y_test)
print('Training data r-squared -', round(r_squared*100,4),'%')
print('Testing data r-squared -', round(r_squared_test*100,4),'%')

#Applying model on Actual data
dataset_act = pd.read_csv(r'C:\slys\data\SirionLabsSample_Act.csv')

dataset_act.rename(columns = {'Average Delivery Time':'AverageDeliveryTime'}, inplace = True)
dataset_act.rename(columns = {'Number of Escalations':'NumberofEscalations'}, inplace = True)


dataset_act_regions = pd.get_dummies(dataset_act['Region'])
dataset_act = dataset_act.join(dataset_act_regions)
dataset_act.drop('Region',axis=1, inplace=True)

dataset_act_functions = pd.get_dummies(dataset_act['Function'])
dataset_act = dataset_act.join(dataset_act_functions)
dataset_act.drop('Function',axis=1, inplace=True)

dataset_act_service = pd.get_dummies(dataset_act['Services'])
dataset_act = dataset_act.join(dataset_act_service)
dataset_act.drop('Services',axis=1, inplace=True)

dataset_country = pd.get_dummies(dataset_act['Country'])
dataset_act = dataset_act.join(dataset_country)
dataset_act.drop('Country',axis=1, inplace=True)


x_act = dataset.iloc[:,1:-1].values

# Prediction of actual data
y_test_data_pred = logReg.predict(x_act)

#Displaying results
x_key = pd.DataFrame(dataset_act['Supplier Name'])
dataset_test_result = pd.DataFrame({'Selected Flag':y_test_data_pred})
dataset_test_result = dataset_test_result.astype(int)
merged = pd.concat([x_key,dataset_test_result],axis=1)

merged['Selected Flag'] = merged['Selected Flag'].map({1:'Y', 0:'N'})



merged.to_csv(r'C:\slys\extracts\extract_models_SirionLabsSample_Act.csv' , index=False)