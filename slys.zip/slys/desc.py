import pandas as pd

dataset = pd.read_csv(r'C:\Users\91998\Downloads\SirionLabsSample_New.csv')
dataset.describe().to_csv(r'C:\slys\extracts\extract_SirionLabsSample_New.csv')