import pandas as pd

dataset = pd.read_csv(r'C:\Users\91998\Downloads\SirionLabsSample.csv')


dataset.rename(columns = {'Average Delivery Time':'AverageDeliveryTime'}, inplace = True)
dataset.rename(columns = {'Number of Escalations':'NumberofEscalations'}, inplace = True)
new_dataset = dataset[(dataset.Resources== dataset.Resources.max()) | (dataset.Rating== dataset.Rating.max()) | (dataset.NumberofEscalations== dataset.NumberofEscalations.min()) | (dataset.AverageDeliveryTime== dataset.AverageDeliveryTime.min()) ]
new_dataset.to_csv(r'C:\slys\\extracts\extract_rules_SirionLabsSample.csv' , index=False)